/**
 * Fetch the MiDaS v2.1 small ONNX model into models/.
 * Usage: npm run fetch-model   (run inside the extension directory)
 */

import { mkdir, writeFile, access } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SOURCES = [
  'https://github.com/isl-org/MiDaS/releases/download/v2_1/model-small.onnx',
  'https://huggingface.co/julienkay/sentis-MiDaS/resolve/main/midas_v21_small_256.onnx',
];

const here = path.dirname(fileURLToPath(import.meta.url));
const outPath = path.join(here, '..', 'models', 'midas_v21_small_256.onnx');

try {
  await access(outPath, constants.F_OK);
  console.log(`Model already present: ${outPath}`);
  process.exit(0);
} catch {
  // not present - download
}

await mkdir(path.dirname(outPath), { recursive: true });

let lastErr = null;
for (const url of SOURCES) {
  try {
    console.log(`Downloading ${url} ...`);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.byteLength < 1_000_000) throw new Error('file too small - not a model');
    await writeFile(outPath, buf);
    console.log(`Saved ${outPath} (${(buf.byteLength / 1048576).toFixed(1)} MB)`);
    console.log('Model: MiDaS v2.1 small (Intel ISL), MIT license - https://github.com/isl-org/MiDaS');
    process.exit(0);
  } catch (err) {
    lastErr = err;
    console.error(`  failed: ${err.message}`);
  }
}
console.error('All sources failed. Download one of the URLs above manually into models/midas_v21_small_256.onnx');
process.exit(1);
