#version 300 es
precision highp float;

uniform sampler2D uVideo;   // current video frame
uniform sampler2D uDepth;  // 256x256 nearness map, 1.0 = closest
uniform float uDisparity;   // max horizontal shift as fraction of frame width
uniform float uConvergence; // nearness placed at the screen plane (zero parallax)
uniform int   uMode;        // 0 = 2D passthrough, 1 = anaglyph, 2 = SBS (per-eye pass)
uniform int   uEye;         // +1 or -1 for SBS passes
uniform vec2  uAlign;       // screen alignment offset (UV)

in vec2 vUv;
out vec4 outColor;

vec4 sampleVideo(vec2 uv) {
  // Clamp at the frame edge: cheap disocclusion handling (edge stretch).
  return texture(uVideo, clamp(uv, vec2(0.0), vec2(1.0)));
}

void main() {
  vec2 uv = vUv + uAlign; // screen alignment

  if (uMode == 0) {
    outColor = vec4(sampleVideo(uv).rgb, 1.0);
    return;
  }

  float nearness = texture(uDepth, uv).r;
  float shift = (nearness - uConvergence) * uDisparity;

  if (uMode == 2) {
    // Side-by-side: one pass per eye (viewport is half the canvas).
    // Left eye (uEye = -1) samples +shift (near objects shift left),
    // right eye samples -shift, matching the anaglyph eye convention.
    vec4 c = sampleVideo(uv + vec2(float(-uEye) * shift, 0.0));
    outColor = vec4(c.rgb, 1.0);
    return;
  }

  // Anaglyph (red-cyan, gray/luma conversion to limit retinal rivalry).
  vec3 left  = sampleVideo(uv + vec2(shift, 0.0)).rgb;  // left eye: sample right of center
  vec3 right = sampleVideo(uv - vec2(shift, 0.0)).rgb;  // right eye: sample left of center
  float lLuma = dot(left,  vec3(0.299, 0.587, 0.114));
  float rLuma = dot(right, vec3(0.299, 0.587, 0.114));
  // Red channel from the left view, green+blue from the right view.
  outColor = vec4(lLuma, rLuma, rLuma, 1.0);
}
