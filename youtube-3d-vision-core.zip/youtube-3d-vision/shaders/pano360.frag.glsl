#version 300 es
precision highp float;

// 360-degree mode: render a genuine equirectangular YouTube 360 video on a
// virtual sphere viewport, with mouse/touch drag to look around. This does
// NOT extract surrounding views from a normal flat video - the UI only
// offers it as a viewing mode for real 360 uploads.

uniform sampler2D uVideo;
uniform float uYaw;    // radians
uniform float uPitch;  // radians
uniform float uFov;    // horizontal FOV, radians

in vec2 vUv;
out vec4 outColor;

const float PI = 3.14159265358979;

void main() {
  float lon = uYaw + (vUv.x - 0.5) * uFov;
  float lat = clamp(uPitch - (vUv.y - 0.5) * uFov * 0.5, -PI * 0.5, PI * 0.5);
  vec2 suv = vec2(fract(lon / (2.0 * PI) + 0.5), 0.5 - lat / PI);
  outColor = vec4(texture(uVideo, suv).rgb, 1.0);
}
