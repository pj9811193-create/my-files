/**
 * StereoRenderer: WebGL2 overlay canvas on top of the YouTube video.
 * Renders the video frame with depth-based horizontal disparity for the
 * left/right views. Modes: 2D passthrough, anaglyph (red-cyan),
 * side-by-side, and 360 equirectangular viewing.
 */

import { MAX_DISPARITY_UV, resolveQuality } from './lib/stereo-math.js';

const MODES = { '2d': 0, anaglyph: 1, sbs: 2 };

export class StereoRenderer {
  static async create(video, player, settings) {
    const r = new StereoRenderer(video, player, settings);
    await r.init();
    return r;
  }

  constructor(video, player, settings) {
    this.video = video;
    this.player = player;
    this.settings = settings;
    this.mode = settings.mode;
    this.visible = false;
    this.hasDepth = false;
    this.yaw = 0;
    this.pitch = 0;
    this._lastVideoTime = -1;
    this._lastYaw = 0;
    this._lastPitch = 0;
  }

  async init() {
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'yt3d-canvas';

    // Insert next to the video inside its container (.html5-video-container).
    const parent = this.video.parentNode || this.player;
    parent.appendChild(this.canvas);

    this.gl = this.canvas.getContext('webgl2', { alpha: false, antialias: false, preserveDrawingBuffer: false });
    if (!this.gl) throw new Error('WebGL2 not available');

    const [vert, stereoFrag, panoFrag] = await Promise.all([
      this._fetchShader('fullscreen.vert.glsl'),
      this._fetchShader('stereo.frag.glsl'),
      this._fetchShader('pano360.frag.glsl'),
    ]);
    this.stereoProg = this._buildProgram(vert, stereoFrag);
    this.panoProg = this._buildProgram(vert, panoFrag);

    // Fullscreen triangle.
    const vao = this.gl.createVertexArray();
    this.gl.bindVertexArray(vao);
    const buf = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, buf);
    this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), this.gl.STATIC_DRAW);
    this.gl.enableVertexAttribArray(0);
    this.gl.vertexAttribPointer(0, 2, this.gl.FLOAT, false, 0, 0);
    this._vao = vao;

    // Video texture (updated every rendered frame).
    this.videoTex = this._makeTexture(true);
    // Depth nearness texture (256x256, R8).
    this.depthTex = this._makeTexture(false);
    this.gl.bindTexture(this.gl.TEXTURE_2D, this.depthTex);
    this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.R8, 256, 256, 0, this.gl.RED, this.gl.UNSIGNED_BYTE, null);

    // Overlay geometry tracking.
    this._ro = new ResizeObserver(() => this.fit());
    this._ro.observe(this.video);
    window.addEventListener('resize', this.fit);
    this.fit();
    this._bind360Drag();

    this.setVisible(false);
  }

  _makeTexture(linearVideo) {
    const gl = this.gl;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, linearVideo ? gl.LINEAR : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    return tex;
  }

  async _fetchShader(name) {
    const res = await fetch(chrome.runtime.getURL(`shaders/${name}`));
    return res.text();
  }

  _buildProgram(vertSrc, fragSrc) {
    const gl = this.gl;
    const compile = (type, src) => {
      const sh = gl.createShader(type);
      gl.shaderSource(sh, src);
      gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
        throw new Error(`shader compile failed: ${gl.getShaderInfoLog(sh)}`);
      }
      return sh;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, vertSrc));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, fragSrc));
    gl.bindAttribLocation(prog, 0, 'aPos');
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      throw new Error(`program link failed: ${gl.getProgramInfoLog(prog)}`);
    }
    return prog;
  }

  /** Size the overlay to exactly cover the displayed video. */
  fit = () => {
    if (!this.canvas || !this.video.isConnected) return;
    const parent = this.canvas.parentNode;
    if (!parent) return;
    const vr = this.video.getBoundingClientRect();
    const pr = parent.getBoundingClientRect();
    if (vr.width < 2 || vr.height < 2) return;
    this.canvas.style.left = `${Math.round(vr.left - pr.left)}px`;
    this.canvas.style.top = `${Math.round(vr.top - pr.top)}px`;
    this.canvas.style.width = `${Math.round(vr.width)}px`;
    this.canvas.style.height = `${Math.round(vr.height)}px`;

    const scale = resolveQuality(this.settings.quality).renderScale;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(2, Math.round(vr.width * dpr * scale));
    const h = Math.max(2, Math.round(vr.height * dpr * scale));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  };

  setVisible(v) {
    this.visible = v;
    this.canvas.style.display = v ? 'block' : 'none';
  }

  setMode(mode) {
    this.mode = mode;
    // 360 needs pointer events for drag-lookaround; other modes stay click-through.
    this.canvas.style.pointerEvents = mode === '360' ? 'auto' : 'none';
    this.canvas.style.touchAction = mode === '360' ? 'none' : 'auto';
  }

  setSettings(settings) {
    this.settings = settings;
    this.fit();
  }

  /** Update the depth nearness texture from the worker output. */
  setDepth(f32, w = 256, h = 256) {
    const gl = this.gl;
    const bytes = new Uint8Array(f32.length);
    for (let i = 0; i < f32.length; i++) bytes[i] = Math.max(0, Math.min(255, Math.round(f32[i] * 255)));
    gl.bindTexture(gl.TEXTURE_2D, this.depthTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, w, h, 0, gl.RED, gl.UNSIGNED_BYTE, bytes);
    this.hasDepth = true;
  }

  /** Render the current video frame into the overlay. */
  render(video) {
    if (!this.visible) return;
    const gl = this.gl;
    this.fit();

    // Upload the video frame (only when it actually advanced).
    if (video.currentTime !== this._lastVideoTime) {
      this._lastVideoTime = video.currentTime;
      gl.bindTexture(gl.TEXTURE_2D, this.videoTex);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
    }

    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bindVertexArray(this._vao);

    if (this.mode === '360') {
      gl.useProgram(this.panoProg);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.videoTex);
      this._u(this.panoProg, 'uVideo', '1i', 0);
      this._u(this.panoProg, 'uYaw', '1f', this.yaw);
      this._u(this.panoProg, 'uPitch', '1f', this.pitch);
      this._u(this.panoProg, 'uFov', '1f', 1.6);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      return;
    }

    gl.useProgram(this.stereoProg);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.videoTex);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.depthTex);
    this._u(this.stereoProg, 'uVideo', '1i', 0);
    this._u(this.stereoProg, 'uDepth', '1i', 1);

    const s = this.settings;
    const disparity = MAX_DISPARITY_UV * s.depthStrength * s.eyeSeparation;
    this._u(this.stereoProg, 'uDisparity', '1f', disparity);
    this._u(this.stereoProg, 'uConvergence', '1f', s.convergence);
    this._u(this.stereoProg, 'uAlign', '2f', [s.alignX || 0, s.alignY || 0]);

    if (this.mode === 'sbs') {
      this._u(this.stereoProg, 'uMode', '1i', 2);
      const hw = Math.floor(this.canvas.width / 2);
      const h = this.canvas.height;
      gl.viewport(0, 0, hw, h);
      this._u(this.stereoProg, 'uEye', '1i', -1);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.viewport(hw, 0, this.canvas.width - hw, h);
      this._u(this.stereoProg, 'uEye', '1i', 1);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    } else {
      this._u(this.stereoProg, 'uMode', '1i', this.mode === 'anaglyph' ? 1 : 0);
      this._u(this.stereoProg, 'uEye', '1i', 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
  }

  _u(prog, name, type, value) {
    const gl = this.gl;
    const loc = this._loc(prog, name);
    if (loc === null) return;
    if (type === '1i') gl.uniform1i(loc, value);
    else if (type === '2f') gl.uniform2f(loc, value[0], value[1]);
    else gl.uniform1f(loc, value);
  }

  _loc(prog, name) {
    if (!prog.__id) prog.__id = (this._progSeq = (this._progSeq || 0) + 1);
    if (!this._locCache) this._locCache = new Map();
    const key = prog.__id + ':' + name;
    if (!this._locCache.has(key)) this._locCache.set(key, this.gl.getUniformLocation(prog, name));
    return this._locCache.get(key);
  }

  _bind360Drag() {
    const c = this.canvas;
    // Head-tracked viewing on devices with an orientation sensor (spec 6).
    if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
      let baseline = null;
      window.addEventListener('deviceorientation', (e) => {
        if (this.mode !== '360' || e.alpha == null) return;
        if (baseline == null) baseline = { alpha: e.alpha, beta: e.beta || 0 };
        const a = ((e.alpha - baseline.alpha) * Math.PI) / 180;
        const b = ((e.beta - baseline.beta) * Math.PI) / 180;
        this.yaw += a - this._lastYaw;
        this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch + (b - this._lastPitch)));
        this._lastYaw = a;
        this._lastPitch = b;
      });
    }
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    c.addEventListener('pointerdown', (e) => {
      if (this.mode !== '360') return;
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      c.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    c.addEventListener('pointermove', (e) => {
      if (!dragging || this.mode !== '360') return;
      this.yaw -= (e.clientX - lastX) * 0.005;
      this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch + (e.clientY - lastY) * 0.004));
      lastX = e.clientX;
      lastY = e.clientY;
    });
    const end = () => { dragging = false; };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
  }

  destroy() {
    if (this._ro) this._ro.disconnect();
    window.removeEventListener('resize', this.fit);
    if (this.canvas && this.canvas.parentNode) this.canvas.remove();
    const lose = this.gl && this.gl.getExtension('WEBGL_lose_context');
    if (lose) lose.loseContext();
  }
}
