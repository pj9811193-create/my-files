/**
 * Control panel UI injected into the YouTube player, plus the "3D" player
 * toolbar button. Pure DOM + CSS (styles.css is injected by the manifest).
 */

const SVG_GLASSES = `
<svg viewBox="0 0 36 24" width="100%" height="100%" aria-hidden="true">
  <rect x="1" y="1" width="34" height="22" rx="5" fill="none" stroke="currentColor" stroke-width="2"/>
  <rect x="4" y="5" width="12" height="12" rx="2.5" fill="#e34" opacity="0.85"/>
  <rect x="20" y="5" width="12" height="12" rx="2.5" fill="#2cc" opacity="0.85"/>
  <line x1="18" y1="6" x2="18" y2="16" stroke="currentColor" stroke-width="2"/>
</svg>`;

export class ControlPanel {
  /**
   * @param opts { settings, hooks: {onToggle, onPatch}, }
   */
  constructor(player, { settings, hooks }) {
    this.player = player;
    this.settings = settings;
    this.hooks = hooks;
    this.buildButton();
    this.buildPanel();
  }

  buildButton() {
    const controls = this.player.querySelector('.ytp-right-controls');
    if (!controls || this.player.querySelector('.yt3d-toggle')) return;
    const btn = document.createElement('button');
    btn.className = 'ytp-button yt3d-toggle';
    btn.title = '3D Vision';
    btn.setAttribute('aria-label', 'Toggle 3D Vision panel');
    btn.innerHTML = SVG_GLASSES;
    btn.addEventListener('click', () => {
      const open = this.panel.classList.toggle('yt3d-open');
      btn.classList.toggle('yt3d-active', open || this.settings.enabled);
    });
    controls.appendChild(btn);
    this.button = btn;
  }

  buildPanel() {
    const p = document.createElement('div');
    p.className = 'yt3d-panel';
    p.innerHTML = `
      <div class="yt3d-head">
        <span class="yt3d-title">3D Vision</span>
        <label class="yt3d-switch">
          <input type="checkbox" class="yt3d-enabled" ${this.settings.enabled ? 'checked' : ''}/>
          <span class="yt3d-slider"></span>
        </label>
      </div>
      <div class="yt3d-row yt3d-status">
        <span class="yt3d-dot"></span><span class="yt3d-status-text">Idle</span>
      </div>
      <div class="yt3d-row yt3d-auto">
        <label><input type="checkbox" class="yt3d-autostart" ${this.settings.autoStart ? 'checked' : ''}/> Start 3D automatically</label>
      </div>
      <div class="yt3d-row yt3d-modes" role="radiogroup" aria-label="Output mode">
        <button data-mode="2d">2D</button>
        <button data-mode="anaglyph">Anaglyph</button>
        <button data-mode="sbs">Side-by-side</button>
        <button data-mode="360">360\u00B0</button>
      </div>
      <div class="yt3d-row"><label>Depth strength</label>
        <input type="range" class="yt3d-depth" min="0" max="1" step="0.05"/></div>
      <div class="yt3d-row"><label>Eye separation</label>
        <input type="range" class="yt3d-eye" min="0" max="1" step="0.05"/></div>
      <div class="yt3d-row"><label>Convergence</label>
        <input type="range" class="yt3d-conv" min="0" max="1" step="0.05"/></div>
      <div class="yt3d-row"><label>Align X</label>
        <input type="range" class="yt3d-alignx" min="-0.2" max="0.2" step="0.005"/></div>
      <div class="yt3d-row"><label>Align Y</label>
        <input type="range" class="yt3d-aligny" min="-0.2" max="0.2" step="0.005"/></div>
      <div class="yt3d-row"><label>Quality</label>
        <select class="yt3d-quality">
          <option value="auto">Auto</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select></div>
      <div class="yt3d-row"><label>Backend</label>
        <select class="yt3d-backend">
          <option value="auto">Auto</option>
          <option value="webgpu">WebGPU</option>
          <option value="wasm">WASM (CPU)</option>
        </select></div>
      <div class="yt3d-row yt3d-metrics">
        <span class="yt3d-fps">-- fps</span>
        <span class="yt3d-lat">-- ms</span>
        <span class="yt3d-reuse"></span>
        <span class="yt3d-res"></span>
        <span class="yt3d-gpu"></span>
        <span class="yt3d-render"></span>
        <span class="yt3d-mem"></span>
      </div>
      <div class="yt3d-row yt3d-actions">
        <button class="yt3d-reset">Reset</button>
      </div>
      <div class="yt3d-note"></div>
    `;
    this.player.appendChild(p);
    this.panel = p;

    p.querySelector('.yt3d-enabled').addEventListener('change', (e) => {
      this.hooks.onToggle(e.target.checked);
    });
    p.querySelectorAll('.yt3d-modes button').forEach((b) => {
      b.addEventListener('click', () => {
        this.hooks.onPatch({ mode: b.dataset.mode, enabled: true });
      });
    });
    p.querySelector('.yt3d-depth').addEventListener('input', (e) => this.hooks.onPatch({ depthStrength: +e.target.value }));
    p.querySelector('.yt3d-eye').addEventListener('input', (e) => this.hooks.onPatch({ eyeSeparation: +e.target.value }));
    p.querySelector('.yt3d-conv').addEventListener('input', (e) => this.hooks.onPatch({ convergence: +e.target.value }));
    p.querySelector('.yt3d-alignx').addEventListener('input', (e) => this.hooks.onPatch({ alignX: +e.target.value }));
    p.querySelector('.yt3d-aligny').addEventListener('input', (e) => this.hooks.onPatch({ alignY: +e.target.value }));
    p.querySelector('.yt3d-quality').addEventListener('change', (e) => this.hooks.onPatch({ quality: e.target.value }));
    p.querySelector('.yt3d-backend').addEventListener('change', (e) => this.hooks.onPatch({ backend: e.target.value }));
    p.querySelector('.yt3d-autostart').addEventListener('change', (e) => this.hooks.onPatch({ autoStart: e.target.checked }));
    p.querySelector('.yt3d-reset').addEventListener('click', () => this.hooks.onReset());

    this.sync(this.settings);
  }

  sync(settings) {
    this.settings = settings;
    this.panel.querySelector('.yt3d-enabled').checked = settings.enabled;
    const autoEl = this.panel.querySelector('.yt3d-autostart');
    if (autoEl) autoEl.checked = !!settings.autoStart;
    this.panel.querySelector('.yt3d-depth').value = settings.depthStrength;
    this.panel.querySelector('.yt3d-eye').value = settings.eyeSeparation;
    this.panel.querySelector('.yt3d-conv').value = settings.convergence;
    this.panel.querySelector('.yt3d-alignx').value = settings.alignX;
    this.panel.querySelector('.yt3d-aligny').value = settings.alignY;
    this.panel.querySelector('.yt3d-quality').value = settings.quality;
    this.panel.querySelector('.yt3d-backend').value = settings.backend;
    this.panel.querySelectorAll('.yt3d-modes button').forEach((b) => {
      b.classList.toggle('yt3d-sel', b.dataset.mode === settings.mode);
    });
    if (this.button) {
      this.button.classList.toggle('yt3d-active', settings.enabled || this.panel.classList.contains('yt3d-open'));
    }
  }

  /** status: {state, backend, error} from the worker or pipeline. */
  setStatus(status) {
    const dot = this.panel.querySelector('.yt3d-dot');
    const text = this.panel.querySelector('.yt3d-status-text');
    const map = {
      idle: ['', 'Idle'],
      'loading-model': ['loading', 'Loading AI model\u2026'],
      'downloading-model': ['loading', status.error ? `Getting the 3D model \u2014 ${status.error} (first time only)` : 'Getting the 3D model (first time only)\u2026'],
      ready: ['ok', `AI depth active (${status.backend || ''})`],
      error: ['err', status.error ? `Error: ${truncate(status.error, 90)}` : 'Error'],
      protected: ['err', 'This video\u2019s frames cannot be processed (protected content). Playback is unchanged.'],
    };
    const [cls, label] = map[status.state] || map.idle;
    dot.className = `yt3d-dot ${cls}`;
    text.textContent = label;
    if (status.state === 'ready' && status.backend) {
      this.panel.querySelector('.yt3d-gpu').textContent = status.backend === 'webgpu' ? 'GPU' : 'CPU';
    }
  }

  setStats(stats) {
    if (!this.settings.showStats) {
      this.panel.querySelector('.yt3d-metrics').style.display = 'none';
      return;
    }
    this.panel.querySelector('.yt3d-metrics').style.display = '';
    this.panel.querySelector('.yt3d-fps').textContent = `${stats.displayFps} fps`;
    this.panel.querySelector('.yt3d-lat').textContent = `${stats.inferMs} ms`;
    this.panel.querySelector('.yt3d-reuse').textContent = `reuse ${Math.round((stats.reuseRatio || 0) * 100)}%`;
    const resEl = this.panel.querySelector('.yt3d-res');
    if (resEl) resEl.textContent = stats.renderScale != null && stats.renderScale < 1
      ? `res ${Math.round(stats.renderScale * 100)}%` : '';
    const memEl = this.panel.querySelector('.yt3d-mem');
    if (memEl) memEl.textContent = stats.memMB != null ? `${stats.memMB} MB` : '';
  }

  /** Which rendering API is in use (WebGPU or WebGL2 fallback). */
  setRendererInfo(name) {
    const el = this.panel.querySelector('.yt3d-render');
    if (el) el.textContent = name;
  }

  note(text) {
    this.panel.querySelector('.yt3d-note').textContent = text || '';
  }

  destroy() {
    if (this.button && this.button.parentNode) this.button.remove();
    if (this.panel && this.panel.parentNode) this.panel.remove();
  }
}

function truncate(s, n) {
  return s.length > n ? s.slice(0, n) + '\u2026' : s;
}
