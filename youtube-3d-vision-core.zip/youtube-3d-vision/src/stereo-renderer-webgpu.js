/**
 * WebGPURenderer: WebGPU stereo renderer (the modern successor to WebGL2 -
 * note there is no "WebGL3"; the API after WebGL2 is WebGPU).
 *
 * Same public interface as StereoRenderer (WebGL2), selected by
 * renderer-factory.js when WebGPU is available. Shaders are WGSL.
 *
 * - Video frames are sampled via device.importExternalTexture (zero-copy
 *   video import, re-imported per frame as required by the API).
 * - The depth nearness map is an R8Unorm texture updated with writeTexture.
 * - Side-by-side renders in a SINGLE pass: the fragment shader selects the
 *   eye view from the horizontal position (uv.x < 0.5 -> left eye).
 */

const STEREO_WGSL = /* wgsl */ `
struct Uniforms {
  disparity: f32,     // max horizontal shift in UV units
  convergence: f32,   // nearness at the screen plane
  mode: u32,          // 0 = 2D, 1 = anaglyph, 2 = SBS (single pass)
  eye: i32,           // unused in single-pass SBS (kept for layout parity)
  yaw: f32,           // 360 mode
  pitch: f32,         // 360 mode
  fov: f32,            // 360 mode
  alignX: f32,         // screen alignment
  alignY: f32,         // screen alignment
  _pad0: f32,
  _pad1: f32,
};

@group(0) @binding(0) var videoTex: texture_external;
@group(0) @binding(1) var videoSamp: sampler;
@group(0) @binding(2) var depthTex: texture_2d<f32>;
@group(0) @binding(3) var depthSamp: sampler;
@group(0) @binding(4) var<uniform> u: Uniforms;

struct VSOut {
  @builtin(position) pos: vec4<f32>,
  @location(0) uv: vec2<f32>,
};

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> VSOut {
  var out: VSOut;
  let p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  out.pos = vec4<f32>(p[vi], 0.0, 1.0);
  // NDC -> uv; NDC y is up, texture coords y is down.
  out.uv = vec2<f32>((p[vi].x + 1.0) * 0.5, 1.0 - (p[vi].y + 1.0) * 0.5);
  return out;
}

fn sampleVideo(uv: vec2<f32>) -> vec4<f32> {
  // Edge-clamped sampling: cheap disocclusion handling (edge stretch).
  let c = clamp(uv, vec2<f32>(0.0), vec2<f32>(1.0));
  return textureSampleBaseClampToEdge(videoTex, videoSamp, c);
}

@fragment
fn fs(in: VSOut) -> @location(0) vec4<f32> {
  let uv = in.uv + vec2<f32>(u.alignX, u.alignY); // screen alignment
  if (u.mode == 0u) {
    return sampleVideo(uv);
  }

  let nearness = textureSampleLevel(depthTex, depthSamp, uv, 0.0).r;
  let shift = (nearness - u.convergence) * u.disparity;

  if (u.mode == 2u) {
    // Single-pass SBS: left half of the canvas = left-eye view,
    // right half = right-eye view. Left eye samples +shift (near objects
    // shift left), right eye samples -shift.
    let isLeft = in.uv.x < 0.5; // canvas halves define the eyes
    let su = vec2<f32>(fract(uv.x * 2.0), uv.y); // uv.x stays in [0,1]
    let shifted = select(su - vec2<f32>(shift, 0.0), su + vec2<f32>(shift, 0.0), isLeft);
    return sampleVideo(shifted);
  }

  // Anaglyph (red-cyan, luma conversion to limit retinal rivalry):
  // red from the left view, green+blue from the right view.
  let lc = sampleVideo(uv + vec2<f32>(shift, 0.0)).rgb;
  let rc = sampleVideo(uv - vec2<f32>(shift, 0.0)).rgb;
  let lLuma = dot(lc, vec3<f32>(0.299, 0.587, 0.114));
  let rLuma = dot(rc, vec3<f32>(0.299, 0.587, 0.114));
  return vec4<f32>(lLuma, rLuma, rLuma, 1.0);
}
`;

const PANO_WGSL = /* wgsl */ `
struct Uniforms {
  disparity: f32,
  convergence: f32,
  mode: u32,
  eye: i32,
  yaw: f32,
  pitch: f32,
  fov: f32,
  _pad: f32,
};

@group(0) @binding(0) var videoTex: texture_external;
@group(0) @binding(1) var videoSamp: sampler;
@group(0) @binding(4) var<uniform> u: Uniforms;

struct VSOut {
  @builtin(position) pos: vec4<f32>,
  @location(0) uv: vec2<f32>,
};

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> VSOut {
  var out: VSOut;
  let p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  out.pos = vec4<f32>(p[vi], 0.0, 1.0);
  out.uv = vec2<f32>((p[vi].x + 1.0) * 0.5, 1.0 - (p[vi].y + 1.0) * 0.5);
  return out;
}

const PI: f32 = 3.14159265358979;

@fragment
fn fs(in: VSOut) -> @location(0) vec4<f32> {
  let lon = u.yaw + (in.uv.x - 0.5) * u.fov;
  let lat = clamp(u.pitch - (in.uv.y - 0.5) * u.fov * 0.5, -PI * 0.5, PI * 0.5);
  let su = vec2<f32>(fract(lon / (2.0 * PI) + 0.5), 0.5 - lat / PI);
  return textureSampleBaseClampToEdge(videoTex, videoSamp, vec2<f32>(su.x, clamp(su.y, 0.0, 1.0)));
}
`;

import { MAX_DISPARITY_UV, resolveQuality } from './lib/stereo-math.js';

export class WebGPURenderer {
  static async create(video, player, settings) {
    const r = new WebGPURenderer(video, player, settings);
    try {
      await r.init();
      return r;
    } catch (err) {
      r.destroy();
      throw err;
    }
  }

  constructor(video, player, settings) {
    this.video = video;
    this.player = player;
    this.settings = settings;
    this.mode = settings.mode;
    this.visible = false;
    this.yaw = 0;
    this.pitch = 0;
    this._lastVideoTime = -1;
    this.backendName = 'WebGPU';
    // Presentation watchdog: set by the orchestrator; called once if the
    // canvas stays fully black after several renders (broken WebGPU
    // compositing, seen on some headless/software-GPU environments).
    this.onFailure = null;
    this._renderCount = 0;
    this._probeDone = false;
    this._lastYaw = 0;
    this._lastPitch = 0;
  }

  async init() {
    if (typeof navigator === 'undefined' || !navigator.gpu) {
      throw new Error('WebGPU not available');
    }
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) throw new Error('no WebGPU adapter');

    this.canvas = document.createElement('canvas');
    this.canvas.className = 'yt3d-canvas';
    const parent = this.video.parentNode || this.player;
    parent.appendChild(this.canvas);

    this.device = await adapter.requestDevice();
    this.device.onuncapturederror = (e) => {
      console.warn('[YT3D webgpu] device error:', e.error && e.error.message);
    };
    this.device.lost.then((info) => {
      if (info.reason !== 'destroyed') console.warn('[YT3D webgpu] device lost:', info.message);
    });
    this.ctx = this.canvas.getContext('webgpu');
    this.format = navigator.gpu.getPreferredCanvasFormat();
    this.ctx.configure({ device: this.device, format: this.format, alphaMode: 'opaque' });

    // Uniform buffer (48 bytes, 12 slots).
    this._udata = new ArrayBuffer(48);
    this._uf = new Float32Array(this._udata);
    this._uu = new Uint32Array(this._udata);
    this.uniformBuf = this.device.createBuffer({ size: 48, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });

    // Samplers.
    this.videoSampler = this.device.createSampler({
      magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge',
    });
    this.depthSampler = this.device.createSampler({
      magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge',
    });

    // Depth nearness texture (256x256, R8Unorm).
    this.depthSize = 256;
    this.depthTex = this.device.createTexture({
      size: [this.depthSize, this.depthSize],
      format: 'r8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST,
    });
    this.depthView = this.depthTex.createView();
    // Initialize to zero (all-far) so the first frames behave predictably.
    this.device.queue.writeTexture(
      { texture: this.depthTex },
      new Uint8Array(this.depthSize * this.depthSize),
      { bytesPerRow: this.depthSize, rowsPerImage: this.depthSize },
      [this.depthSize, this.depthSize]
    );

    // Bind group layout shared by both pipelines.
    this.bgl = this.device.createBindGroupLayout({
      entries: [
        { binding: 0, visibility: GPUShaderStage.FRAGMENT, externalTexture: {} },
        { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
        { binding: 2, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float' } },
        { binding: 3, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
        { binding: 4, visibility: GPUShaderStage.FRAGMENT, buffer: {} },
      ],
    });
    const layout = this.device.createPipelineLayout({ bindGroupLayouts: [this.bgl] });

    const makePipeline = async (code) => {
      const module = this.device.createShaderModule({ code });
      if (module.getCompilationInfo) {
        const info = await module.getCompilationInfo();
        const errors = info.messages.filter((m) => m.type === 'error');
        if (errors.length) throw new Error('WGSL compile error: ' + errors.map((m) => m.message).join('; '));
      }
      return this.device.createRenderPipeline({
        layout,
        vertex: { module, entryPoint: 'vs' },
        fragment: { module, entryPoint: 'fs', targets: [{ format: this.format }] },
        primitive: { topology: 'triangle-list' },
      });
    };
    this.stereoPipeline = await makePipeline(STEREO_WGSL);
    this.panoPipeline = await makePipeline(PANO_WGSL);

    this._ro = new ResizeObserver(() => this.fit());
    this._ro.observe(this.video);
    window.addEventListener('resize', this.fit);
    this.fit();
    this._bind360Drag();
    this.setVisible(false);
  }

  fit = () => {
    if (!this.canvas || !this.video.isConnected) return;
    const parent = this.canvas.parentNode;
    if (!parent) return;
    const vr = this.video.getBoundingClientRect();
    const pr = parent.getBoundingClientRect();
    if (vr.width < 2 || vr.height < 2) return;
    this.canvas.style.left = `${Math.round(vr.left - pr.left)}px`;
    this.canvas.style.top = `${Math.round(vr.top - pr.top)}px`;
    this.canvas.style.width = `${Math.round(vr.width)}px`;
    this.canvas.style.height = `${Math.round(vr.height)}px`;

    const scale = resolveQuality(this.settings.quality).renderScale * (this._scaleOverride || 1);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(2, Math.round(vr.width * dpr * scale));
    const h = Math.max(2, Math.round(vr.height * dpr * scale));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  };

  setVisible(v) {
    this.visible = v;
    this.canvas.style.display = v ? 'block' : 'none';
  }

  setMode(mode) {
    this.mode = mode;
    this.canvas.style.pointerEvents = mode === '360' ? 'auto' : 'none';
    this.canvas.style.touchAction = mode === '360' ? 'none' : 'auto';
  }

  setSettings(settings) {
    this.settings = settings;
    this.fit();
  }

  setRenderScale(scale) {
    this._scaleOverride = scale;
    this.fit();
  }

  setDepth(f32, w = 256, h = 256) {
    if (!this.device) return;
    if (!this._depthBytes || this._depthBytes.length !== f32.length) {
      this._depthBytes = new Uint8Array(f32.length);
    }
    const bytes = this._depthBytes;
    for (let i = 0; i < f32.length; i++) bytes[i] = Math.max(0, Math.min(255, Math.round(f32[i] * 255)));
    const rowLen = Math.min(w, this.depthSize);
    this.device.queue.writeTexture(
      { texture: this.depthTex },
      bytes,
      { bytesPerRow: rowLen, rowsPerImage: h },
      [Math.min(w, this.depthSize), Math.min(h, this.depthSize)]
    );
  }

  render(video) {
    if (this._destroyed || !this.visible || !this.device) return;
    // No per-frame fit(): see the WebGL2 renderer note - layout reads here
    // cost a synchronous reflow every frame.

    const s = this.settings;
    const disparity = MAX_DISPARITY_UV * s.depthStrength * s.eyeSeparation;

    let pipeline;
    if (this.mode === '360') {
      pipeline = this.panoPipeline;
      this._uf[4] = this.yaw;
      this._uf[5] = this.pitch;
      this._uf[6] = 1.6; // horizontal FOV
      this._uu[2] = 3;   // unused by pano
    } else {
      pipeline = this.stereoPipeline;
      this._uf[0] = disparity;
      this._uf[1] = s.convergence;
      this._uu[2] = this.mode === 'sbs' ? 2 : this.mode === 'anaglyph' ? 1 : 0;
      this._uu[3] = 0;
      this._uf[7] = s.alignX || 0;
      this._uf[8] = s.alignY || 0;
    }
    this.device.queue.writeBuffer(this.uniformBuf, 0, this._udata);

    // External textures are single-frame scoped: import per render.
    let external;
    try {
      external = this.device.importExternalTexture({ source: video });
    } catch (err) {
      return; // frame not importable (e.g. protected content mid-switch)
    }

    const bind = this.device.createBindGroup({
      layout: this.bgl,
      entries: [
        { binding: 0, resource: external },
        { binding: 1, resource: this.videoSampler },
        { binding: 2, resource: this.depthView },
        { binding: 3, resource: this.depthSampler },
        { binding: 4, resource: { buffer: this.uniformBuf } },
      ],
    });

    const encoder = this.device.createCommandEncoder();
    const pass = encoder.beginRenderPass({
      colorAttachments: [{
        view: this.ctx.getCurrentTexture().createView(),
        clearValue: { r: 0, g: 0, b: 0, a: 1 },
        loadOp: 'clear',
        storeOp: 'store',
      }],
    });
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bind);
    pass.draw(3);
    pass.end();
    this.device.queue.submit([encoder.finish()]);

    this._renderCount += 1;
    if (!this._probeDone && this._renderCount === 10) {
      this._probeDone = true;
      this._presentationProbe();
    }
  }

  /**
   * Verify that the canvas actually presents content: draw it into a 2D
   * canvas and look for any non-black pixels. A playing video must produce
   * some; if not, WebGPU presentation is broken here and we ask the
   * orchestrator to fall back to the WebGL2 renderer.
   */
  _presentationProbe() {
    try {
      const c = document.createElement('canvas');
      c.width = 32;
      c.height = 18;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(this.canvas, 0, 0, 32, 18);
      const d = ctx.getImageData(0, 0, 32, 18).data;
      let sum = 0;
      for (let i = 0; i < d.length; i += 4) sum += d[i] + d[i + 1] + d[i + 2];
      if (sum <= 0 && typeof this.onFailure === 'function') {
        console.warn('[YT3D] WebGPU canvas presents no content - falling back to WebGL2');
        this.onFailure();
      }
    } catch (_) {
      // Probe is best-effort; ignore readback failures.
    }
  }

  _bind360Drag() {
    const c = this.canvas;
    // Head-tracked viewing on devices with an orientation sensor (spec 6).
    if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
      let baseline = null;
      window.addEventListener('deviceorientation', (e) => {
        if (this.mode !== '360' || e.alpha == null) return;
        if (baseline == null) baseline = { alpha: e.alpha, beta: e.beta || 0 };
        const a = ((e.alpha - baseline.alpha) * Math.PI) / 180;
        const b = ((e.beta - baseline.beta) * Math.PI) / 180;
        this.yaw += a - this._lastYaw;
        this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch + (b - this._lastPitch)));
        this._lastYaw = a;
        this._lastPitch = b;
      });
    }
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    c.addEventListener('pointerdown', (e) => {
      if (this.mode !== '360') return;
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      c.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    c.addEventListener('pointermove', (e) => {
      if (!dragging || this.mode !== '360') return;
      this.yaw -= (e.clientX - lastX) * 0.005;
      this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch + (e.clientY - lastY) * 0.004));
      lastX = e.clientX;
      lastY = e.clientY;
    });
    const end = () => { dragging = false; };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
  }

  destroy() {
    this._destroyed = true;
    if (this._ro) this._ro.disconnect();
    window.removeEventListener('resize', this.fit);
    if (this.canvas && this.canvas.parentNode) this.canvas.remove();
    if (this.device) {
      // Drain pending GPU work before destroying the device - destroying
      // mid-submit can crash some WebGPU implementations.
      const dev = this.device;
      const kill = () => { try { dev.destroy(); } catch (_) {} };
      if (dev.queue && dev.queue.onSubmittedWorkDone) {
        dev.queue.onSubmittedWorkDone().then(kill, kill);
      } else {
        kill();
      }
      this.device = null;
    }
  }
}
