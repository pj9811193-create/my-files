/**
 * FrameProcessor: drives per-frame rendering and adaptive depth inference.
 *
 * Rendering: every presented video frame (requestVideoFrameCallback, with a
 * rAF fallback) is passed to the StereoRenderer.
 * Inference: at most one in-flight inference; a new frame is only captured
 * when the previous one finished AND the quality-profile interval elapsed.
 * If inference latency is persistently above budget, the effective interval
 * is stretched (frame skipping) and, in 'auto' quality, the profile is
 * downgraded.
 */

import { resolveQuality, QUALITY_PROFILES } from './lib/stereo-math.js';

export class FrameProcessor {
  constructor({ video, worker, renderer, getSettings, onDepth, onStats }) {
    this.video = video;
    this.worker = worker;
    this.renderer = renderer;
    this.getSettings = getSettings;
    this.onDepth = onDepth;
    this.onStats = onStats;

    this.running = false;
    this._handle = 0;          // rVFC/rAF handle
    this._inFlight = false;
    this._lastInferAt = 0;
    this._effectiveIntervalMs = 300;
    this._autoQuality = 'medium';
    this._latencyEma = 0;

    // Temporal depth blending: a fresh depth map fades in over a few frames
    // instead of snapping. Depth arrives far less often than the display
    // refreshes, so this is what makes the 3D look smooth rather than steppy.
    this._depthFrom = null;    // map we are blending away from
    this._depthShown = null;   // map currently on screen (also the blend output)
    this._depthTarget = null;  // newest map from the worker
    this._depthW = 256;
    this._depthH = 256;
    this._blendElapsed = 0;
    this._blendDurMs = 140;

    // Adaptive overlay resolution (auto quality only), driven by measured FPS.
    this._autoScale = 1;
    this._scaleSwitches = 0;

    this.stats = {
      displayFps: 0,
      inferMs: 0,
      reuseRatio: 0,
      rendered: 0,
      inferred: 0,
      reused: 0,
      memMB: null,
    };
    this._fpsFrames = 0;
    this._fpsWindowStart = performance.now();
    this._memTimer = setInterval(() => this._sampleMemory(), 2000);
  }

  /** JS heap readout for the memory monitor (Chrome exposes performance.memory). */
  _sampleMemory() {
    try {
      const m = performance.memory;
      this.stats.memMB = m ? Math.round(m.usedJSHeapSize / 1048576) : null;
    } catch (_) {
      this.stats.memMB = null;
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.worker.addEventListener('message', this._onWorkerMessage);
    this._loop();
    this._statsTimer = setInterval(() => this._publishStats(), 1000);
  }

  /** The main thread calls this once the worker reports its session ready. */
  setReady(ready) {
    this.ready = ready;
    if (!ready) this._inFlight = false;
  }

  stop() {
    this.running = false;
    clearInterval(this._statsTimer);
    clearInterval(this._memTimer);
    this.worker.removeEventListener('message', this._onWorkerMessage);
  }

  /**
   * rAF-driven loop. Rendering continues even while the video is paused so
   * that control changes remain live; the video texture itself is only
   * re-uploaded by the renderer when currentTime advances. Depth inference
   * is additionally gated on new frames.
   */
  _loop = () => {
    if (!this.running) return;
    requestAnimationFrame(() => {
      if (!this.running) return;
      const now = performance.now();
      const newFrame = this.video.currentTime !== this._lastVideoTime;
      this._lastVideoTime = this.video.currentTime;

      // Render (with FPS cap from the quality profile).
      const settings = this.getSettings();
      const profile = this._activeProfile(settings);
      const minFrameMs = 1000 / profile.maxFps;
      if (!this._lastRenderAt || now - this._lastRenderAt >= minFrameMs - 1) {
        this._advanceBlend(now);
        this.renderer.render(this.video);
        this.stats.rendered += 1;
        this._fpsFrames += 1;
        this._lastRenderAt = now;
      }

      // Maybe kick off a depth inference (model ready + new frame + interval).
      if (
        this.ready &&
        newFrame &&
        !this._inFlight &&
        this.video.readyState >= 2 &&
        now - this._lastInferAt >= this._effectiveIntervalMs
      ) {
        this._lastInferAt = now;
        this._inFlight = true;
        createImageBitmap(this.video, {
          resizeWidth: 256,
          resizeHeight: 256,
          resizeQuality: 'low',
        })
          .then((bitmap) => {
            this.worker.postMessage({ type: 'infer', bitmap }, [bitmap]);
          })
          .catch(() => {
            // Frame not readable right now (seek, DRM, ...) - just skip it.
            this._inFlight = false;
          });
      }
      this._loop();
    });
  };

  _activeProfile(settings) {
    const q = settings.quality === 'auto' ? this._autoQuality : settings.quality;
    return resolveQuality(q);
  }

  _onWorkerMessage = (e) => {
    const msg = e.data;
    if (msg.type === 'status' && msg.state === 'error') {
      this._inFlight = false; // unstick the pipeline on worker errors
      return;
    }
    if (msg.type === 'depth') {
      this._inFlight = false;
      this._depthW = msg.width;
      this._depthH = msg.height;
      if (msg.reused) {
        // The scene barely moved: the map on screen already equals this one.
        // Skip the GPU upload entirely.
        this.stats.reused += 1;
      } else {
        this.stats.inferred += 1;
        if (!this._depthShown) {
          // First map: show it at once, nothing to blend from.
          this._depthShown = msg.depth.slice();
          this._depthTarget = this._depthShown;
          this.renderer.setDepth(this._depthShown, msg.width, msg.height);
        } else {
          if (!this._depthFrom || this._depthFrom.length !== msg.depth.length) {
            this._depthFrom = new Float32Array(msg.depth.length);
          }
          this._depthFrom.set(this._depthShown);
          this._depthTarget = msg.depth;
          this._blendElapsed = 0; // start (or restart) the fade
        }
      }
      this.stats.inferMs = Math.round(msg.ms);

      // Latency EMA + adaptive interval (never infer more often than 2.5x latency).
      this._latencyEma = this._latencyEma ? 0.7 * this._latencyEma + 0.3 * msg.ms : msg.ms;
      const settings = this.getSettings();
      const base = this._activeProfile(settings).inferIntervalMs;
      // Keep depth reasonably fresh: wait only ~1.3x the measured inference
      // time (not 2.5x), and never let the gap grow past 1.2 s.
      this._effectiveIntervalMs = Math.min(1200, Math.max(base, this._latencyEma * 1.3));

      // Auto quality: downgrade after sustained overrun, upgrade when healthy.
      if (settings.quality === 'auto' && this._autoSwitches < 4) {
        if (this._autoQuality === 'high' && this._latencyEma > 450) { this._autoQuality = 'medium'; this._autoSwitches++; }
        else if (this._autoQuality === 'medium' && this._latencyEma > 700) { this._autoQuality = 'low'; this._autoSwitches++; }
        else if (this._autoQuality === 'low' && this._latencyEma < 200) { this._autoQuality = 'medium'; this._autoSwitches++; }
      }
      if (this.onDepth) this.onDepth(msg);
    }
  };

  _autoSwitches = 0;

  /**
   * Step the depth fade by the time since the last displayed frame and hand
   * the blended map to the renderer. Cheap: 256x256 lerp, no allocation.
   */
  _advanceBlend(now) {
    if (!this._depthShown || !this._depthTarget) return;
    if (this._depthTarget === this._depthShown) return; // settled
    const dt = this._lastBlendAt ? now - this._lastBlendAt : 16;
    this._lastBlendAt = now;
    this._blendElapsed += dt;
    const t = Math.min(1, this._blendElapsed / this._blendDurMs);
    const from = this._depthFrom;
    const to = this._depthTarget;
    const out = this._depthShown;
    for (let i = 0; i < out.length; i++) out[i] = from[i] + (to[i] - from[i]) * t;
    if (t >= 1) {
      out.set(to);
      this._depthTarget = out; // settled: stop blending until the next map
    }
    this.renderer.setDepth(out, this._depthW, this._depthH);
  }

  _publishStats() {
    const now = performance.now();
    const secs = (now - this._fpsWindowStart) / 1000;
    this.stats.displayFps = Math.round(this._fpsFrames / Math.max(secs, 0.001));

    // Auto quality also adapts the overlay RESOLUTION to the measured frame
    // rate: if the display cannot keep up, render fewer pixels (the overlay is
    // scaled up by the browser), and restore detail once it is comfortable.
    const settings = this.getSettings();
    if (settings.quality === 'auto' && this._scaleSwitches < 6) {
      if (this.stats.displayFps > 0 && this.stats.displayFps < 20 && this._autoScale > 0.75) {
        this._autoScale = Math.max(0.75, this._autoScale - 0.25);
        this._scaleSwitches += 1;
        if (this.renderer.setRenderScale) this.renderer.setRenderScale(this._autoScale);
      } else if (this.stats.displayFps >= 45 && this._autoScale < 1) {
        this._autoScale = Math.min(1, this._autoScale + 0.25);
        this._scaleSwitches += 1;
        if (this.renderer.setRenderScale) this.renderer.setRenderScale(this._autoScale);
      }
    }
    this.stats.renderScale = this._autoScale;
    this._fpsFrames = 0;
    this._fpsWindowStart = now;
    this.stats.reuseRatio = this.stats.inferred + this.stats.reused
      ? this.stats.reused / (this.stats.inferred + this.stats.reused)
      : 0;
    if (this.onStats) this.onStats({ ...this.stats });
  }
}
