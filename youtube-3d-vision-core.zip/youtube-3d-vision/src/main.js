/**
 * Main orchestrator (runs in the content-script isolated world).
 * Wires together: video detection -> renderer + worker + frame processor +
 * control panel, and manages the enabled/disabled lifecycle.
 */

import { VideoDetector, probeFrameAccess } from './video-detector.js';
import { createRenderer } from './renderer-factory.js';
import { StereoRenderer } from './stereo-renderer.js';
import { FrameProcessor } from './frame-processor.js';
import { ControlPanel } from './panel.js';
import { SettingsStore, mergeSettings, DEFAULTS } from './settings.js';
import { createExtensionWorker } from './lib/worker-launch.js';

export async function start() {
  const store = new SettingsStore();
  let settings = await store.get();

  let renderer = null;
  let panel = null;
  let worker = null;
  let processor = null;
  let currentVideo = null;
  let currentPlayer = null;

  const applySettings = (patch) => {
    settings = mergeSettings({ ...settings, ...patch });
    if (panel) panel.sync(settings);
    if (renderer) {
      renderer.setSettings(settings);
      renderer.setMode(settings.mode);
    }
  };

  const handlePatch = async (patch) => {
    applySettings(patch);
    await store.set(patch);
    if ('backend' in patch && currentVideo) {
      // Renderer choice depends on the backend - rebuild the whole overlay.
      await teardown();
      await setupFor(currentVideo, currentPlayer);
    }
    if ('enabled' in patch && patch.enabled !== undefined) {
      await setEnabled(patch.enabled);
    }
  };

  const handleReset = async () => {
    await store.set(DEFAULTS);
    applySettings({ ...DEFAULTS, enabled: false });
    await setEnabled(false);
    applySettings(DEFAULTS);
  };

  async function teardown() {
    if (processor) { processor.stop(); processor = null; }
    if (worker) { worker.terminate(); worker = null; }
    if (panel) { panel.destroy(); panel = null; }
    if (renderer) { renderer.destroy(); renderer = null; }
  }

  async function setEnabled(on) {
    if (on) {
      if (!renderer || !currentVideo) return;
      if (processor) return; // already running (e.g. mode change re-fired enable)
      let workerReady = false;
      // 1. Make sure frames are readable (DRM / cross-origin protection).
      const probe = probeFrameAccess(currentVideo);
      if (!probe.ok && String(probe.reason).startsWith('blocked')) {
        panel.setStatus({ state: 'error', error: 'Video frames are not readable in this context.' });
        return;
      }
      // Black frames may just be a paused video at t=0; re-probe after play if needed.
      if (!probe.ok && probe.reason === 'black-frames' && currentVideo.readyState >= 2) {
        panel.setStatus({ state: 'protected' });
        return;
      }
      // 2. Start the inference worker (blob-based launch, see worker-launch.js).
      try {
        worker = await createExtensionWorker('src/depth-engine.js');
      } catch (err) {
        panel.setStatus({ state: 'error', error: `worker launch failed: ${err.message}` });
        return;
      }
      worker.addEventListener('error', (e) => {
        panel.setStatus({ state: 'error', error: e.message || 'worker error' });
      });
      worker.addEventListener('message', (e) => {
        const msg = e.data;
        if (msg.type === 'cache-stored') {
          // Model is now cached on this site's IndexedDB: from now on every
          // video starts instantly. Relay to the background for the popup.
          try { chrome.runtime.sendMessage({ type: 'model-cached', cached: true }); } catch (_) {}
        }
        if (msg.type === 'status') {
          if (msg.state === 'ready') {
            workerReady = true;
            if (processor) processor.setReady(true);
            panel.note('');
          }
          if (msg.state === 'error') panel.note(msg.error);
          panel.setStatus(msg);
        }
      });
      // The worker loads the model itself: this site's IndexedDB cache
      // (instant after first use) or a one-time CDN download. No manual
      // download step and no background round-trip needed.
      worker.postMessage({
        type: 'init',
        backend: settings.backend,
        modelUrl: chrome.runtime.getURL('models/midas_v21_small_256.onnx'),
        wasmPaths: chrome.runtime.getURL('vendor/onnxruntime-web/'),
      });

      // 3. Start rendering + frame capture.
      renderer.setMode(settings.mode);
      renderer.setVisible(true);
      processor = new FrameProcessor({
        video: currentVideo,
        worker,
        renderer,
        getSettings: () => settings,
        onStats: (stats) => panel.setStats(stats),
      });
      if (workerReady) processor.setReady(true);
      processor.start();
      panel.setStatus({ state: 'loading-model' });
    } else {
      if (processor) { processor.stop(); processor = null; }
      if (worker) { worker.terminate(); worker = null; }
      if (renderer) {
        renderer.setVisible(false);
        renderer.setMode('2d');
      }
      panel.setStatus({ state: 'idle' });
    }
  }

  const setupFor = async (video, player) => {
    try {
      renderer = await createRenderer(video, player, settings);
      if (panel) panel.setRendererInfo(renderer.backendName || 'WebGL2');
    } catch (err) {
      console.warn('[YT3D] renderer unavailable:', err);
      return;
    }
    panel = new ControlPanel(player, {
      settings,
      hooks: { onToggle: (on) => handlePatch({ enabled: on }), onPatch: handlePatch, onReset: handleReset },
    });
    panel.setRendererInfo(renderer.backendName || 'WebGL2');

    // Runtime fallback: if the WebGPU canvas turns out not to present
    // content (broken compositor, e.g. some software-GPU environments),
    // swap in the WebGL2 renderer and restart the pipeline if needed.
    if (typeof renderer.onFailure === 'function') {
      renderer.onFailure = async () => {
        const wasEnabled = !!processor;
        if (processor) { processor.stop(); processor = null; }
        if (worker) { worker.terminate(); worker = null; }
        renderer.destroy();
        try {
          renderer = await StereoRenderer.create(video, player, settings);
        } catch (err) {
          console.warn('[YT3D] WebGL2 fallback failed too:', err);
          return;
        }
        renderer.setSettings(settings);
        renderer.setMode(settings.mode);
        if (panel) panel.setRendererInfo(renderer.backendName || 'WebGL2');
        if (wasEnabled) await setEnabled(true);
      };
    }

    // Re-apply persisted enabled state after navigation.
    if (settings.enabled) await setEnabled(true);
    else panel.setStatus({ state: 'idle' });
  };

  const detector = new VideoDetector(async (targets) => {
    await teardown();
    if (!targets) { currentVideo = null; currentPlayer = null; return; }
    currentVideo = targets.video;
    currentPlayer = targets.player;
    await setupFor(currentVideo, currentPlayer);
  });
  detector.start();

  // Keep multiple tabs in sync when settings change elsewhere.
  // The change event carries only changed keys - merge onto the CURRENT
  // settings, not onto defaults (otherwise unrelated keys like `enabled`
  // would be reset to their defaults).
  store.subscribe((changes) => {
    const wasEnabled = settings.enabled;
    settings = mergeSettings({ ...settings, ...changes });
    if (panel) panel.sync(settings);
    if (renderer) { renderer.setSettings(settings); renderer.setMode(settings.mode); }
    if (settings.enabled !== wasEnabled) setEnabled(settings.enabled);
  });
}
