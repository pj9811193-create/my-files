/**
 * Detects the active YouTube player + <video> element and keeps track of it
 * across YouTube's SPA navigation, mode changes and fullscreen toggles.
 */

const scanThrottleMs = 500;

export class VideoDetector {
  /**
   * @param {(targets: {video: HTMLVideoElement, player: HTMLElement} | null) => void} onChange
   *   Called with the current video/player pair whenever it changes, or with
   *   null when the previously detected video disappears from the document.
   */
  constructor(onChange) {
    this.onChange = onChange;
    this.video = null;
    this.player = null;
    this._lastScan = 0;
    this._scanTimer = null;
  }

  start() {
    window.addEventListener('yt-navigate-finish', () => this.scheduleScan(0));
    document.addEventListener('fullscreenchange', () => this.scheduleScan(0));
    this._observer = new MutationObserver(() => this.scheduleScan());
    this._observer.observe(document.body, { childList: true, subtree: true });
    this.scheduleScan(0);
  }

  stop() {
    if (this._observer) this._observer.disconnect();
    clearTimeout(this._scanTimer);
  }

  scheduleScan(delay = scanThrottleMs) {
    const now = Date.now();
    if (now - this._lastScan < delay) {
      if (!this._scanTimer) {
        this._scanTimer = setTimeout(() => { this._scanTimer = null; this.scan(); }, delay);
      }
      return;
    }
    this.scan();
  }

  scan() {
    this._lastScan = Date.now();
    const video =
      document.querySelector('video.html5-main-video') ||
      document.querySelector('#movie_player video') ||
      document.querySelector('video');
    const player = document.querySelector('#movie_player');

    const stillThere = this.video && document.contains(this.video);
    if (!stillThere && this.video) {
      this.video = null;
      this.player = null;
      this.onChange(null);
    }

    if (video && player && video !== this.video) {
      this.video = video;
      this.player = player;
      this.onChange({ video, player });
    }
  }
}

/**
 * Probe whether frames of this video can be read locally.
 * Returns { ok: boolean, reason: string }.
 *  - drawImage throwing SecurityError -> cross-origin/tainted frame
 *  - fully black readback -> EME/DRM-protected content (playback untouched)
 */
export function probeFrameAccess(video) {
  try {
    const c = document.createElement('canvas');
    c.width = 32;
    c.height = 32;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(video, 0, 0, 32, 32);
    const data = ctx.getImageData(0, 0, 32, 32).data;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i] !== 0 || data[i + 1] !== 0 || data[i + 2] !== 0) {
        return { ok: true, reason: 'ok' };
      }
    }
    return { ok: false, reason: 'black-frames' };
  } catch (err) {
    return { ok: false, reason: `blocked: ${err && err.name}` };
  }
}
