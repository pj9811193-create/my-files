/**
 * Renderer factory: prefer the modern WebGPU stereo renderer (note: there
 * is no "WebGL3" - the API that follows WebGL2 is WebGPU), and fall back to
 * the WebGL2 renderer when WebGPU is unavailable or fails to initialize.
 *
 * backend setting: 'auto' | 'webgpu' -> try WebGPU first, then WebGL2.
 *                   'wasm'           -> WebGL2 only (CPU-oriented preset).
 */

import { StereoRenderer } from './stereo-renderer.js';
import { WebGPURenderer } from './stereo-renderer-webgpu.js';

export async function createRenderer(video, player, settings) {
  const wantGpu = settings.backend === 'auto' || settings.backend === 'webgpu';
  if (wantGpu && typeof navigator !== 'undefined' && navigator.gpu) {
    try {
      return await WebGPURenderer.create(video, player, settings);
    } catch (err) {
      console.warn('[YT3D] WebGPU renderer unavailable, falling back to WebGL2:', err && err.message);
    }
  }
  const r = await StereoRenderer.create(video, player, settings);
  r.backendName = 'WebGL2';
  return r;
}
