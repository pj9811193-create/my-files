/**
 * Depth inference worker (module Web Worker).
 * Runs the MiDaS v2.1 small ONNX model via ONNX Runtime Web, fully locally.
 *
 * Protocol (from the main thread):
 *   {type:'init', backend}                          -> status messages
 *   {type:'infer', bitmap: ImageBitmap}             -> {type:'depth', ...}
 * Back to the main thread:
 *   {type:'status', state, backend, error}
 *   {type:'depth', depth: Float32Array(256*256), width, height, ms, reused}
 */

import * as ort from '../vendor/onnxruntime-web/ort.all.min.mjs';
import { normalizeNearness, grayThumb32, shouldReuseDepth } from './lib/depth-post.js';
import { idbGet, idbPut } from './lib/idb.js';
import { MODEL_FILE, fetchModelFromCDN } from './lib/model-store.js';

const INPUT_SIZE = 256;

// Provided by the main thread in the init message (blob workers have no
// access to chrome.* APIs).
let modelUrl = null;
let modelBytes = null;
let wasmPaths = null;

// ImageNet normalization used by MiDaS v2.1 (matches upstream export).
const MEAN = [0.485, 0.456, 0.406];
const STD = [0.229, 0.224, 0.225];

let session = null;
let inputTensor = null;  // reused across inferences (no per-frame allocation)
let backendUsed = 'none';
let initError = null;
let lastDepth = null;   // Float32Array nearness map
let lastGray = null;   // 32x32 grayscale thumb of the last inferred frame
let lastBitmaps = 0, reusedCount = 0;

// Reusable offscreen canvas for pixel readback.
const workCanvas = new OffscreenCanvas(INPUT_SIZE, INPUT_SIZE);
const workCtx = workCanvas.getContext('2d', { willReadFrequently: true });

self.onmessage = (e) => {
  const msg = e.data;
  try {
    if (msg.type === 'init') init(msg);
    else if (msg.type === 'infer') runInference(msg.bitmap);
    else if (msg.type === 'stats') postStats();
  } catch (err) {
    postStatus('error', String(err && err.message || err));
  }
};

function postStatus(state, error = null) {
  self.postMessage({ type: 'status', state, backend: backendUsed, error });
}

function postStats() {
  self.postMessage({
    type: 'stats',
    backend: backendUsed,
    inferences: lastBitmaps,
    reused: reusedCount,
    reuseRatio: lastBitmaps ? reusedCount / (lastBitmaps + reusedCount) : 0,
  });
}

async function loadModelBuffer() {
  // 0. Model bytes transferred in by the main thread, if provided.
  if (modelBytes && modelBytes.byteLength > 1_000_000) {
    return new Uint8Array(modelBytes);
  }

  // 1. Model file bundled into the extension's models/ directory (dev path).
  try {
    if (modelUrl) {
      const res = await fetch(modelUrl);
      if (res.ok) {
        const buf = await res.arrayBuffer();
        if (buf.byteLength > 1_000_000) return new Uint8Array(buf);
      }
    }
  } catch (_) { /* fall through */ }

  // 2. Cached in this site's IndexedDB by a previous run (instant: the whole
  //    model is stored once, so later videos never download anything again).
  try {
    const blob = await idbGet(MODEL_FILE);
    if (blob && blob.size > 1_000_000) return new Uint8Array(await blob.arrayBuffer());
  } catch (_) { /* fall through */ }

  // 3. One-time fetch from a public CDN mirror (HuggingFace mirrors send
  //    CORS headers, so this works directly from the page). Stored whole
  //    into IndexedDB for instant reuse. The GitHub release asset is tried
  //    first but does not send CORS headers from page context, so in
  //    practice the HuggingFace mirrors serve the file.
  postStatus('downloading-model', '0%');
  let lastPct = -1;
  const bytes = await fetchModelFromCDN((p) => {
    const pct = p.total ? Math.round((p.loaded / p.total) * 100) : null;
    if (pct !== null && pct > lastPct) {
      lastPct = pct;
      postStatus('downloading-model', pct + '%');
    }
  });
  try {
    await idbPut(MODEL_FILE, new Blob([bytes], { type: 'application/octet-stream' }));
    self.postMessage({ type: 'cache-stored' }); // tell the main thread the cache is now warm
  } catch (_) { /* cache is best-effort */ }
  return bytes;
}

async function init(opts = {}) {
  modelUrl = opts.modelUrl || null;
  modelBytes = opts.modelBytes || null;
  wasmPaths = opts.wasmPaths || null;
  postStatus('loading-model');
  try {
    const bytes = await loadModelBuffer();

    // YouTube pages are not cross-origin isolated -> no SharedArrayBuffer ->
    // wasm must run single-threaded.
    ort.env.wasm.numThreads = 1;
    if (wasmPaths) ort.env.wasm.wasmPaths = wasmPaths;

    const wantGpu = (opts.backend === 'auto' || opts.backend === 'webgpu') &&
      typeof navigator !== 'undefined' && !!navigator.gpu;

    if (wantGpu) {
      try {
        session = await ort.InferenceSession.create(bytes, { executionProviders: ['webgpu'] });
        backendUsed = 'webgpu';
      } catch (err) {
        console.warn('[YT3D worker] WebGPU failed, falling back to wasm:', err);
        session = null;
      }
    }
    if (!session) {
      session = await ort.InferenceSession.create(bytes, { executionProviders: ['wasm'] });
      backendUsed = 'wasm';
    }
    postStatus('ready');
  } catch (err) {
    initError = String(err && err.message || err);
    postStatus('error', initError);
  }
}

async function runInference(bitmap) {
  const t0 = performance.now();
  try {
    if (!session) {
      bitmap.close();
      postStatus('loading-model'); // init still in flight; retry on a later frame
      return;
    }

    // Draw the frame and read pixels.
    workCtx.drawImage(bitmap, 0, 0, INPUT_SIZE, INPUT_SIZE);
    const rgba = workCtx.getImageData(0, 0, INPUT_SIZE, INPUT_SIZE).data;
    bitmap.close();

    // Temporal reuse: if the scene barely moved since the last inference,
    // keep the previous depth map instead of re-running the network.
    const gray = grayThumb32(rgba, INPUT_SIZE);
    if (shouldReuseDepth(lastGray, gray)) {
      reusedCount += 1;
      if (lastDepth) {
        const copy = lastDepth.slice();
        self.postMessage(
          { type: 'depth', depth: copy, width: INPUT_SIZE, height: INPUT_SIZE, ms: performance.now() - t0, reused: true },
          [copy.buffer]
        );
        return;
      }
    }
    lastGray = gray;

    // Build the NCHW float32 input tensor. The buffer and the Tensor object
    // are reused between inferences - allocating ~196 KB per frame is pure
    // garbage-collector pressure on the render thread's critical path.
    const plane = INPUT_SIZE * INPUT_SIZE;
    if (!inputTensor) {
      inputTensor = new ort.Tensor('float32', new Float32Array(3 * plane), [1, 3, INPUT_SIZE, INPUT_SIZE]);
    }
    const data = inputTensor.data;
    for (let i = 0; i < plane; i++) {
      const r = rgba[i * 4] / 255, g = rgba[i * 4 + 1] / 255, b = rgba[i * 4 + 2] / 255;
      data[i] = (r - MEAN[0]) / STD[0];
      data[plane + i] = (g - MEAN[1]) / STD[1];
      data[2 * plane + i] = (b - MEAN[2]) / STD[2];
    }

    const feeds = {};
    feeds[session.inputNames[0]] = inputTensor;
    const results = await session.run(feeds);
    const raw = results[session.outputNames[0]];

    const depth = normalizeNearness(raw.data);
    lastDepth = depth;
    lastBitmaps += 1;

    const out = depth.slice(); // transfer a copy; keep the original for reuse
    self.postMessage(
      { type: 'depth', depth: out, width: INPUT_SIZE, height: INPUT_SIZE, ms: performance.now() - t0, reused: false },
      [out.buffer]
    );
  } catch (err) {
    postStatus('error', `inference failed: ${err && err.message}`);
  }
}
