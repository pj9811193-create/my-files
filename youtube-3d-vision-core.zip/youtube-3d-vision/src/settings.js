/**
 * Settings model + chrome.storage wrapper.
 * mergeSettings is pure and unit-tested in Node.
 */

export const DEFAULTS = Object.freeze({
  enabled: false,          // master toggle
  autoStart: true,         // turn 3D on by itself when a video is detected
  mode: 'anaglyph',        // '2d' | 'sbs' | 'anaglyph' | '360'
  depthStrength: 0.5,       // overall 3D effect strength 0..1
  eyeSeparation: 0.5,      // interaxial amount 0..1
  convergence: 0.45,       // nearness placed at the screen plane 0..1
  alignX: 0,               // screen alignment, horizontal UV offset -0.2..0.2
  alignY: 0,               // screen alignment, vertical UV offset -0.2..0.2
  quality: 'auto',         // 'auto' | 'low' | 'medium' | 'high'
  backend: 'auto',         // 'auto' | 'wasm' | 'webgpu'
  showStats: true,
});

const BOUNDS = {
  enabled: null,
  autoStart: null,
  mode: ['2d', 'sbs', 'anaglyph', '360'],
  depthStrength: [0, 1],
  eyeSeparation: [0, 1],
  convergence: [0, 1],
  alignX: [-0.2, 0.2],
  alignY: [-0.2, 0.2],
  quality: ['auto', 'low', 'medium', 'high'],
  backend: ['auto', 'wasm', 'webgpu'],
  showStats: null,
};

/** Merge a settings patch onto defaults: unknown keys dropped, values clamped/validated. */
export function mergeSettings(patch = {}) {
  const out = { ...DEFAULTS };
  for (const key of Object.keys(DEFAULTS)) {
    if (!(key in patch)) continue;
    const val = patch[key];
    const bound = BOUNDS[key];
    if (bound === null) {
      out[key] = val;
    } else if (typeof bound[0] === 'string') {
      // enum list
      if (typeof val === 'string' && bound.includes(val)) out[key] = val;
    } else if (typeof val === 'number' && Number.isFinite(val)) {
      // [min, max] numeric range
      out[key] = Math.min(bound[1], Math.max(bound[0], val));
    }
  }
  return out;
}

/** Thin async wrapper around an injected storage area (chrome.storage.sync by default). */
export class SettingsStore {
  constructor(area) {
    this.area = area || (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) || null;
  }

  async get() {
    if (!this.area) return { ...DEFAULTS };
    return mergeSettings(await this.area.get(null));
  }

  async set(patch) {
    if (this.area) await this.area.set(patch);
    return mergeSettings(patch); // echo back the sanitized value
  }

  subscribe(fn) {
    if (!this.area) return () => {};
    // Delivers ONLY the changed keys; the caller merges them onto current state.
    const listener = (changes) => fn(Object.fromEntries(
      Object.entries(changes).map(([k, v]) => [k, v.newValue])
    ));
    this.area.onChanged.addListener(listener);
    return () => this.area.onChanged.removeListener(listener);
  }
}
