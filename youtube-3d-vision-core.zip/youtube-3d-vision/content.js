/**
 * YouTube 3D Vision - content script entry point.
 * MV3 content scripts cannot be ES modules, so this loader dynamically
 * imports the real entry module from the extension bundle.
 */
(async () => {
  try {
    const main = await import(chrome.runtime.getURL('src/main.js'));
    await main.start();
  } catch (err) {
    console.error('[YT3D] failed to start:', err);
  }
})();
