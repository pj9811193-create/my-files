/**
 * Popup: plain-language settings + model readiness.
 *
 * The readiness card is INSTANT in every situation:
 *  — inside the extension, the remembered result is painted immediately
 *    (synchronous) and the real check runs quietly afterwards, correcting
 *    the card only if the answer changed;
 *  — outside the extension (this file opened as a web page or preview),
 *    a plain ready card is shown at once — there is nothing to check.
 */

const $ = (id) => document.getElementById(id);
const card = $('modelcard');

function showCard(state, title, text) {
  card.className = 'card ' + state;
  card.querySelector('.cardtitle').innerHTML = title;
  card.querySelector('.cardtext').innerHTML = text;
}

const READY_TITLE = '<span class="done">✓ Everything is ready</span>';
const CACHE_KEY = 'yt3d-ready-state';

/** Paint a readiness state ('bundled' | 'relay' | 'auto' | null). */
function paint(state) {
  if (state === 'relay') {
    showCard('ok', READY_TITLE, '3D works right away on any YouTube video.');
  } else if (state === 'auto') {
    showCard('busy', 'Almost hands-free',
      'The first time you turn on 3D on a video, it gets the 3D brain by itself ' +
      '(about one minute, just once). No downloads to manage, nothing to click.');
  } else {
    // 'bundled' and unknown (first ever open): the ready card — for the
    // shipped package this is simply true, and the quiet check below
    // corrects it within a moment if it ever is not.
    showCard('ok', READY_TITLE,
      '3D works right away on any YouTube video — no downloads, ever.');
  }
}

const inExtension = typeof chrome !== 'undefined' &&
  !!(chrome.runtime && chrome.runtime.id);

if (!inExtension) {
  // Opened as a plain web page (for example as a preview on the download
  // site): show the ready state immediately — nothing to check here.
  showCard('ok', READY_TITLE,
    'Nothing to set up — the 3D brain is included in the package. ' +
    'You are looking at the settings window as a preview: once the add-on is ' +
    'loaded in Chrome on a computer, the 3D button appears under YouTube videos.');
} else {
  // Instant first paint from the remembered state (synchronous).
  let remembered = null;
  try { remembered = localStorage.getItem(CACHE_KEY); } catch (_) { }
  paint(remembered);

  // The real check — started by popup-early.js before this file loaded.
  async function bundledModelPresent() {
    try { return window.__bundledCheck ? await window.__bundledCheck : false; }
    catch (_) { return false; }
  }

  function askRelay() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'model-status' }, (res) => {
          resolve(res && res.cached ? 'relay' : 'auto');
        });
      } catch (_) { resolve('auto'); }
    });
  }

  (async () => {
    let state = (await bundledModelPresent()) ? 'bundled' : null;
    if (!state) state = await askRelay(); // no bundled file: report the CDN setup
    try { localStorage.setItem(CACHE_KEY, state); } catch (_) { }
    if (state !== remembered) paint(state); // correct the card only if it changed
  })();
}

// Settings (same storage keys as before).
async function loadSettings() {
  try {
    const { DEFAULTS } = await import('./src/settings.js');
    const stored = await chrome.storage.sync.get(null);
    const settings = { ...DEFAULTS, ...stored };
    $('mode').value = settings.mode;
    $('quality').value = settings.quality;
    $('backend').value = settings.backend;
  } catch (_) { /* preview context: the dropdowns simply keep their defaults */ }
}
loadSettings();

if (inExtension) {
  for (const key of ['mode', 'quality', 'backend']) {
    $(key).addEventListener('change', (e) => chrome.storage.sync.set({ [key]: e.target.value }));
  }
}
