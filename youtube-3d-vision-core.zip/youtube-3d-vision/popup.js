/**
 * Popup: plain-language settings + model readiness.
 *
 * The readiness card is INSTANT: the result from the last time is remembered
 * in localStorage (a synchronous read, so it is painted before anything
 * async even starts). The real check still runs every time — it just runs
 * quietly in the background and only touches the card if the answer changed.
 */

const $ = (id) => document.getElementById(id);
const card = $('modelcard');

function showCard(state, title, text) {
  card.className = 'card ' + state;
  card.querySelector('.cardtitle').innerHTML = title;
  card.querySelector('.cardtext').innerHTML = text;
}

const CACHE_KEY = 'yt3d-ready-state';

/** Paint a readiness state ('bundled' | 'relay' | 'auto' | null). */
function paint(state) {
  if (state === 'bundled') {
    showCard('ok', '<span class="done">✓ Everything is ready</span>',
      '3D works right away on any YouTube video — no downloads, ever.');
  } else if (state === 'relay') {
    showCard('ok', '<span class="done">✓ Everything is ready</span>',
      '3D works right away on any YouTube video.');
  } else if (state === 'auto') {
    showCard('busy', 'Almost hands-free',
      'The first time you turn on 3D on a video, it gets the 3D brain by itself ' +
      '(about one minute, just once). No downloads to manage, nothing to click.');
  } else {
    showCard('', 'Checking things are ready…', 'This takes a moment.');
  }
}

// Instant first paint from the remembered state (synchronous, zero delay).
let remembered = null;
try { remembered = localStorage.getItem(CACHE_KEY); } catch (_) { }
paint(remembered);

// The real check — started by the script in <head>, before this file loaded.
async function bundledModelPresent() {
  try { return window.__bundledCheck ? await window.__bundledCheck : false; }
  catch (_) { return false; }
}

function askRelay() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'model-status' }, (res) => {
        resolve(res && res.cached ? 'relay' : 'auto');
      });
    } catch (_) { resolve('auto'); }
  });
}

(async () => {
  let state = (await bundledModelPresent()) ? 'bundled' : null;
  if (!state) state = await askRelay(); // no bundled file: report the CDN setup
  try { localStorage.setItem(CACHE_KEY, state); } catch (_) { }
  if (state !== remembered) paint(state); // correct the card only if it changed
})();

// Settings (same storage keys as before).
async function loadSettings() {
  const { DEFAULTS } = await import('./src/settings.js');
  const stored = await chrome.storage.sync.get(null);
  const settings = { ...DEFAULTS, ...stored };
  $('mode').value = settings.mode;
  $('quality').value = settings.quality;
  $('backend').value = settings.backend;
}
loadSettings();

for (const key of ['mode', 'quality', 'backend']) {
  $(key).addEventListener('change', (e) => chrome.storage.sync.set({ [key]: e.target.value }));
}
