/**
 * Popup: plain-language settings + model readiness.
 *
 * There is no "download" button anywhere: the AI model gets itself ready
 * automatically the first time 3D is enabled on a video (fetched once from
 * a public CDN mirror and stored whole in IndexedDB — after that every
 * video starts instantly with zero downloads). This popup simply reports
 * what YouTube tabs have told us this session.
 */

const $ = (id) => document.getElementById(id);
const card = $('modelcard');

function showCard(state, title, text) {
  card.className = 'card ' + state;
  card.querySelector('.cardtitle').innerHTML = title;
  card.querySelector('.cardtext').innerHTML = text;
}

// The model ships inside the extension: check it directly (cheap - the
// response resolves as soon as headers arrive, before any body is read).
async function bundledModelPresent() {
  try {
    const res = await fetch(chrome.runtime.getURL('models/midas_v21_small_256.onnx'));
    if (!res.ok) return false;
    if (res.body) { try { await res.body.cancel(); } catch (_) { /* best effort */ } }
    return true;
  } catch (_) {
    return false;
  }
}

async function refreshModelStatus() {
  // 1. Model bundled with the extension: instant everywhere, zero downloads.
  if (await bundledModelPresent()) {
    showCard('ok', '<span class="done">✓ Everything is ready</span>',
      '3D works right away on any YouTube video \u2014 no downloads, ever.');
    return;
  }
  // 2. No bundled file (e.g. a store-size-limited build): report what
  //    YouTube tabs have told us this session about the automatic CDN setup.
  chrome.runtime.sendMessage({ type: 'model-status' }, (res) => {
    if (res && res.cached) {
      showCard('ok', '<span class="done">✓ Everything is ready</span>',
        '3D works right away on any YouTube video.');
    } else {
      showCard('busy', 'Almost hands-free',
        'The first time you turn on 3D on a video, it gets the 3D brain by itself ' +
        '(about one minute, just once). No downloads to manage, nothing to click.');
    }
  });
}

// Settings (same storage keys as before).
async function loadSettings() {
  const { DEFAULTS } = await import('./src/settings.js');
  const stored = await chrome.storage.sync.get(null);
  const settings = { ...DEFAULTS, ...stored };
  $('mode').value = settings.mode;
  $('quality').value = settings.quality;
  $('backend').value = settings.backend;
}
loadSettings();

for (const key of ['mode', 'quality', 'backend']) {
  $(key).addEventListener('change', (e) => chrome.storage.sync.set({ [key]: e.target.value }));
}

refreshModelStatus();
