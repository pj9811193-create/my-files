/**
 * FrameProcessor: temporal depth blending + reused-map handling.
 * Uses fakes, so it runs headless in Node with no DOM or GPU.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { FrameProcessor } from '../src/frame-processor.js';

class FakeRenderer {
  constructor() { this.calls = []; }
  setDepth(f) { this.calls.push(Float32Array.from(f)); }
  render() {}
  setRenderScale() {}
}
class FakeWorker {
  addEventListener() {}
  removeEventListener() {}
  postMessage() {}
}
function makeProc() {
  const renderer = new FakeRenderer();
  const proc = new FrameProcessor({
    video: { currentTime: 0, readyState: 2 },
    worker: new FakeWorker(),
    renderer,
    getSettings: () => ({ quality: 'auto' }),
    onDepth() {},
    onStats() {},
  });
  return { proc, renderer };
}
const depthMsg = (vals, reused = false) => ({
  data: { type: 'depth', depth: Float32Array.from(vals), width: 2, height: 2, ms: 5, reused },
});

test('the first depth map is shown at once (nothing to blend from)', () => {
  const { proc, renderer } = makeProc();
  proc._onWorkerMessage(depthMsg([0, 0, 0, 0]));
  assert.deepEqual(Array.from(renderer.calls.at(-1)), [0, 0, 0, 0]);
  proc.stop();
});

test('a new depth map fades in: intermediate frames lie strictly between the two maps', () => {
  const { proc, renderer } = makeProc();
  proc._onWorkerMessage(depthMsg([0, 0, 0, 0]));
  proc._onWorkerMessage(depthMsg([1, 1, 1, 1]));

  proc._advanceBlend(100);
  const mid = renderer.calls.at(-1);
  assert.ok(mid.every((v) => v > 0 && v < 1), `expected an in-between map, got ${Array.from(mid)}`);

  proc._advanceBlend(140);
  const later = renderer.calls.at(-1);
  assert.ok(later.every((v) => v > mid[0]), 'the blend keeps progressing toward the new map');

  proc._advanceBlend(500);
  assert.deepEqual(Array.from(renderer.calls.at(-1)), [1, 1, 1, 1], 'settles exactly on the new map');
  proc.stop();
});

test('a reused depth map is not re-uploaded (the scene did not move)', () => {
  const { proc, renderer } = makeProc();
  proc._onWorkerMessage(depthMsg([0.5, 0.5, 0.5, 0.5]));
  const before = renderer.calls.length;
  proc._onWorkerMessage(depthMsg([0.5, 0.5, 0.5, 0.5], true));
  assert.equal(renderer.calls.length, before, 'no GPU upload for a reused map');
  assert.equal(proc.stats.reused, 1);
  proc.stop();
});

test('render-scale adaptation steps down on a low measured frame rate', () => {
  const { proc, renderer } = makeProc();
  // drive the real fps counter: N frames in the last second
  proc._fpsFrames = 12;
  proc._fpsWindowStart = performance.now() - 1000;
  proc._publishStats();
  assert.equal(proc.stats.displayFps, 12);
  assert.ok(proc._autoScale < 1, 'resolution reduced when frames are slow');
  assert.ok(proc._autoScale >= 0.75, 'but never below the quality floor');

  proc._fpsFrames = 55;               // comfortable again
  proc._fpsWindowStart = performance.now() - 1000;
  proc._publishStats();
  assert.ok(proc._autoScale >= 0.75, 'resolution restored when frames recover');
  proc.stop();
});
