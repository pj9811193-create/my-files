# End-to-end browser test

Requires: Node 18+, `puppeteer-core` installed, a full (non-headless-shell)
Chrome/Chromium binary, and a VP9/WebM test video.

1. Copy `testsite/index.html` to a served root with a `bbb_720_vp9.webm`
   next to it; `localserver.mjs` serves any folder with HTTP Range support
   (set ROOT inside it, default port 8123).
2. Make a test copy of the extension with an extra content-script match for
   `http://127.0.0.1:8123/*` in `manifest.json` (both in `content_scripts`
   and `web_accessible_resources`), place it at `./testext-build`, and put
   the model in its `models/` directory.
3. Run:
   CHROME_BIN=/path/to/chrome node run-e2e.mjs

Results are written to the extension's `tests/results/`.

Note: the sandbox that produced the committed results raised the shell's
`ulimit -S -v` before launching Chrome (a small VM cap otherwise kills the
browser). The on-site run also needed `--enable-unsafe-swiftshader` for
software WebGL2 (already included in the launch args).
