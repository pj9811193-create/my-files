// Tiny static server with HTTP Range support for local video testing.
// Serves ROOT on 127.0.0.1:8123 (primary origin) and 127.0.0.1:8124
// (second origin, used by the protected-content test: cross-origin video
// frames are unreadable from a page on 8123).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const ROOT = '/scratch/work/proj/youtube-3d-vision/tests/e2e/testsite';
const MIME = { '.html': 'text/html', '.webm': 'video/webm', '.js': 'text/javascript' };

const handler = (req, res) => {
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = path.join(ROOT, urlPath === '/' ? 'index.html' : urlPath);
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); res.end(); return; }
  const stat = fs.statSync(file);
  const type = MIME[path.extname(file)] || 'application/octet-stream';
  const range = req.headers.range;
  if (range) {
    const m = /bytes=(\d+)-(\d*)/.exec(range);
    const start = m ? +m[1] : 0;
    const end = m && m[2] ? +m[2] : stat.size - 1;
    res.writeHead(206, {
      'Content-Type': type,
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
    });
    fs.createReadStream(file, { start, end }).pipe(res);
  } else {
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': stat.size, 'Accept-Ranges': 'bytes' });
    fs.createReadStream(file).pipe(res);
  }
};

http.createServer(handler).listen(8123, '127.0.0.1', () => console.log('serving http://127.0.0.1:8123'));
http.createServer(handler).listen(8124, '127.0.0.1', () => console.log('serving http://127.0.0.1:8124'));
