/**
 * Full-automation check: with auto-start on (the shipped default), 3D must
 * turn on BY ITSELF when a video appears - no button, no toggle, no clicks.
 *
 * Harness note: the extension finishes loading a few seconds after the browser
 * starts (measured: no service worker at launch, one after ~4 s), so this test
 * waits for it before opening the page - a page opened in that first instant
 * never receives the content script.
 */
import puppeteer from 'puppeteer-core';

// Note: the sandbox exports CHROME_BIN pointing at a headless *shell*, which
// cannot load extensions at all - ignore that and use the full Chrome build.
const FULL_CHROME = '/scratch/work/chrome-linux64/chrome';
const CHROME = (process.env.CHROME_BIN && !/headless[-_]shell|chromium-headless-shell/.test(process.env.CHROME_BIN))
  ? process.env.CHROME_BIN : FULL_CHROME;
const EXT = process.env.EXT_A || '/scratch/work/proj/youtube-3d-vision/tests/e2e/testext-build';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const record = (n, p, d = '') => { results.push(p); console.log(`${p ? 'PASS' : 'FAIL'}  ${n}${d ? '  (' + d + ')' : ''}`); };

const browser = await puppeteer.launch({
  executablePath: CHROME, headless: true, defaultViewport: { width: 640, height: 420 },
  args: ['--no-sandbox','--disable-setuid-sandbox',`--disable-extensions-except=${EXT}`,`--load-extension=${EXT}`,
         '--disable-dev-shm-usage','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required','--mute-audio'],
});
try {
  await sleep(4000);                     // let the extension come up
  const page = await browser.newPage();
  await page.bringToFront();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto('http://127.0.0.1:8123/', { waitUntil: 'domcontentloaded' });

  // From here on: absolutely no clicks.
  let injected = false;
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    if (await page.evaluate(() => !!document.querySelector('.yt3d-toggle'))) { injected = true; break; }
  }
  record('A0 extension injected itself into the page', injected);

  const t0 = Date.now();
  let readyMs = null, status = '';
  while (Date.now() - t0 < 150000) {
    status = await page.evaluate(() => document.querySelector('.yt3d-status-text')?.textContent || '(no panel yet)');
    if (/AI depth active/.test(status)) { readyMs = Date.now() - t0; break; }
    if (/Error|cannot be processed/.test(status)) break;
    await sleep(1000);
  }
  record('A1 3D started by itself (no clicks at all)', readyMs !== null,
    readyMs ? `${(readyMs / 1000).toFixed(1)}s after the page opened, status "${status}"` : `stuck at "${status}"`);

  const st = await page.evaluate(() => {
    const c = document.querySelector('.yt3d-canvas');
    const box = document.querySelector('.yt3d-panel .yt3d-enabled');
    const auto = document.querySelector('.yt3d-autostart');
    return { canvas: !!c && getComputedStyle(c).display !== 'none', toggle: box ? box.checked : null, auto: auto ? auto.checked : null };
  });
  record('A2 overlay is on screen without any interaction', st.canvas === true, `canvas visible: ${st.canvas}`);
  record('A3 the panel toggle reflects the auto-started state', st.toggle === true, `toggle checked: ${st.toggle}`);
  record('A4 the auto-start option is on by default', st.auto === true, `auto-start checkbox: ${st.auto}`);
  record('A5 no page errors', errors.length === 0, errors[0] ? errors[0].slice(0, 80) : '');
} finally { await browser.close(); }
console.log(`\n${results.filter(Boolean).length}/${results.length} auto-start checks passed`);
