/**
 * Performance harness: measures the real 3D pipeline on the local stand-in.
 *  - time from enabling 3D to first depth map ("AI depth active")
 *  - overlay display FPS, inference latency (ms), depth-reuse ratio over a window
 * Reports measured numbers only. Run with:
 *   CHROME_BIN=... PERF_EXT=<ext dir> node tests/e2e/perf-test.mjs
 */
import puppeteer from 'puppeteer-core';

const CHROME = process.env.CHROME_BIN || '/scratch/work/chrome-linux64/chrome';
const EXT = process.env.PERF_EXT || '/scratch/work/restore/youtube-3d-vision/tests/e2e/testext-build';
const WINDOW_S = Number(process.env.PERF_WINDOW || 18);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({
  executablePath: CHROME, headless: true,
  defaultViewport: { width: 1280, height: 800 },
  args: [
    '--no-sandbox', '--disable-setuid-sandbox',
    `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`,
    '--autoplay-policy=no-user-gesture-required', '--mute-audio',
    '--enable-unsafe-swiftshader', '--disable-dev-shm-usage',
  ],
});
try {
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));

  await page.goto('http://127.0.0.1:8123/', { waitUntil: 'domcontentloaded' });
  await page.bringToFront();
  await page.waitForSelector('.yt3d-toggle', { timeout: 30000 });
  await sleep(1500);
  await page.click('.yt3d-toggle');
  await page.waitForSelector('.yt3d-panel.yt3d-open', { timeout: 15000 });

  // Optional: force a fixed quality so runs are comparable (no adaptive scale).
  const FIXED_Q = process.env.PERF_QUALITY || '';
  if (FIXED_Q) {
    await page.evaluate((q) => {
      const sel = document.querySelector('.yt3d-quality');
      if (sel) { sel.value = q; sel.dispatchEvent(new Event('change', { bubbles: true })); }
    }, FIXED_Q);
    await sleep(1200);
  }

  const backend = await page.evaluate(() => document.querySelector('.yt3d-render')?.textContent || '?');
  if (backend === 'WebGPU') {
    await page.evaluate(() => {
      const sel = document.querySelector('.yt3d-backend');
      sel.value = 'wasm'; sel.dispatchEvent(new Event('change', { bubbles: true }));
    });
    await sleep(2500);
  }

  const t0 = Date.now();
  await page.evaluate(() => document.querySelector('.yt3d-panel .yt3d-enabled').click());

  // wait for first depth map
  let readyMs = null;
  while (Date.now() - t0 < 240000) {
    const txt = await page.evaluate(() => document.querySelector('.yt3d-status-text')?.textContent || '');
    if (/AI depth active/.test(txt)) { readyMs = Date.now() - t0; break; }
    if (/Error|cannot be processed/.test(txt)) { console.log('STATUS ERROR:', txt); break; }
    await sleep(500);
  }

  // sample stats over the window
  const samples = [];
  const tWin = Date.now();
  while (Date.now() - tWin < WINDOW_S * 1000) {
    const s = await page.evaluate(() => {
      const fps = (document.querySelector('.yt3d-fps')?.textContent || '').trim();
      const lat = (document.querySelector('.yt3d-lat')?.textContent || '').trim();
      const reuse = (document.querySelector('.yt3d-reuse')?.textContent || '').trim();
      const res = (document.querySelector('.yt3d-res')?.textContent || '').trim();
      return { fps, lat, reuse, res };
    });
    samples.push(s);
    await sleep(1000);
  }
  const nums = (arr) => arr.map((x) => parseFloat(x)).filter((n) => !isNaN(n));
  const fps = nums(samples.map((s) => s.fps));
  const lat = nums(samples.map((s) => s.lat));
  const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN);
  const med = (a) => { const b = [...a].sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : NaN; };

  console.log(JSON.stringify({
    backend, readyMs,
    displayFps: { samples: fps.length, avg: +avg(fps).toFixed(1), median: med(fps), max: Math.max(...fps) },
    inferMs: { avg: +avg(lat).toFixed(0), median: med(lat), min: Math.min(...lat) },
    reuseLast: samples[samples.length - 1]?.reuse || '',
    resLast: samples[samples.length - 1]?.res || '(full)',
    pageErrors: errors.length,
  }, null, 2));
} finally { await browser.close(); }
