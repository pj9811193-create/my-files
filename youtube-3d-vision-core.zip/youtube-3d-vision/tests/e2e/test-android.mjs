/**
 * Android design check: the add-on must be usable on a phone-sized, touch-only
 * screen - big enough tap targets, a panel that fits the display instead of
 * being clipped inside the player, and the whole pipeline driven by touch.
 *
 * Runs Chrome with a Pixel-class viewport and REAL touch events (CDP).
 */
import puppeteer from 'puppeteer-core';

const FULL_CHROME = '/scratch/work/chrome-linux64/chrome';
const CHROME = (process.env.CHROME_BIN && !/headless[-_]shell/.test(process.env.CHROME_BIN)) ? process.env.CHROME_BIN : FULL_CHROME;
const EXT = process.env.EXT_A || '/scratch/work/proj/youtube-3d-vision/tests/e2e/testext-build';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const record = (n, p, d = '') => { results.push(p); console.log(`${p ? 'PASS' : 'FAIL'}  ${n}${d ? '  (' + d + ')' : ''}`); };

const VIEWPORT = { width: 412, height: 915, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true };

const browser = await puppeteer.launch({
  executablePath: CHROME, headless: true,
  args: ['--no-sandbox', '--disable-setuid-sandbox', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`,
    '--disable-dev-shm-usage', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required', '--mute-audio'],
});
try {
  await sleep(4000);
  const page = await browser.newPage();
  await page.setViewport(VIEWPORT);
  await page.setUserAgent('Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36');
  await page.bringToFront();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  const cdp = await page.createCDPSession();

  const tap = async (sel) => {
    const box = await page.$eval(sel, (el) => { const r = el.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: box.x, y: box.y }] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  };

  await page.goto('http://127.0.0.1:8123/', { waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) { await sleep(1000); if (await page.evaluate(() => !!document.querySelector('.yt3d-toggle'))) break; }
  record('M0 extension injects on a phone-sized page', await page.evaluate(() => !!document.querySelector('.yt3d-toggle')));

  const media = await page.evaluate(() => ({ coarse: matchMedia('(pointer: coarse)').matches, w: innerWidth, h: innerHeight }));
  console.log(`  emulated: ${media.w}x${media.h} css px, pointer:coarse = ${media.coarse}`);

  const btn = await page.$eval('.yt3d-toggle', (el) => { const r = el.getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height) }; });
  record('M1 the 3D button is a finger-sized target (>=44px)', btn.w >= 44 && btn.h >= 44, `${btn.w}x${btn.h} px`);

  await tap('.yt3d-toggle');
  await sleep(600);
  record('M2 tapping the button (touch) opens the panel', await page.evaluate(() => !!document.querySelector('.yt3d-panel.yt3d-open')));

  const fit = await page.evaluate(() => {
    const p = document.querySelector('.yt3d-panel');
    const r = p.getBoundingClientRect();
    return { left: Math.round(r.left), right: Math.round(r.right), bottom: Math.round(r.bottom), w: Math.round(r.width), h: Math.round(r.height),
      vw: innerWidth, vh: innerHeight, pos: getComputedStyle(p).position, radius: getComputedStyle(p).borderTopLeftRadius };
  });
  record('M3 panel is a bottom sheet that fits the screen (not clipped)',
    fit.pos === 'fixed' && fit.left >= -1 && fit.right <= fit.vw + 1 && fit.bottom <= fit.vh + 1 && fit.bottom >= fit.vh - 2,
    `position:${fit.pos} left:${fit.left} right:${fit.right} bottom:${fit.bottom} of ${fit.vw}x${fit.vh}, radius ${fit.radius}`);

  const small = await page.evaluate(() => {
    const bad = [];
    // For a checkbox the real tap target is its wrapping label.
    const targets = document.querySelectorAll('.yt3d-panel button, .yt3d-panel select, .yt3d-panel input[type="range"], .yt3d-switch, .yt3d-auto label');
    for (const el of targets) {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && r.height < 40) bad.push(`${el.className || el.type}:${Math.round(r.width)}x${Math.round(r.height)}`);
    }
    return bad;
  });
  record('M4 every control has a touch-sized hit area', small.length === 0, small.length ? small.slice(0, 4).join(', ') : 'all controls >=40px tall');

  await page.evaluate(() => { const sw = document.querySelector('.yt3d-panel .yt3d-enabled'); if (sw && sw.checked) sw.click(); });
  await sleep(400);
  await tap('.yt3d-panel .yt3d-enabled + .yt3d-slider');
  await sleep(800);
  const onAfterTap = await page.evaluate(() => document.querySelector('.yt3d-panel .yt3d-enabled')?.checked);
  record('M5 tapping the on/off switch with a finger turns 3D on', onAfterTap === true, `switch checked: ${onAfterTap}`);

  const before = await page.evaluate(() => +document.querySelector('.yt3d-panel .yt3d-depth').value);
  const sl = await page.$eval('.yt3d-panel .yt3d-depth', (el) => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y + r.height / 2, w: r.width }; });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: sl.x + sl.w * 0.2, y: sl.y }] });
  for (let k = 1; k <= 5; k++) {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: sl.x + sl.w * (0.2 + 0.1 * k), y: sl.y }] });
    await sleep(60);
  }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await sleep(400);
  const after = await page.evaluate(() => +document.querySelector('.yt3d-panel .yt3d-depth').value);
  record('M6 dragging the depth slider with a finger changes it', after > before, `${before} -> ${after}`);

  const t0 = Date.now();
  let status = '', ready = false;
  while (Date.now() - t0 < 150000) {
    status = await page.evaluate(() => document.querySelector('.yt3d-status-text')?.textContent || '');
    if (/AI depth active/.test(status)) { ready = true; break; }
    if (/Error|cannot be processed/.test(status)) break;
    await sleep(1000);
  }
  record('M7 depth inference runs on the phone-sized screen', ready, `status "${status}"`);

  const out = await page.evaluate(() => {
    const c = document.querySelector('.yt3d-canvas');
    if (!c) return { visible: false };
    return { visible: getComputedStyle(c).display !== 'none', w: c.width, h: c.height };
  });
  record('M8 stereo overlay is on screen at the phone size', out.visible === true, `canvas ${out.w}x${out.h}`);
  record('M9 no page errors', errors.length === 0, errors[0] ? errors[0].slice(0, 80) : '');
} finally { await browser.close(); }
console.log(`\n${results.filter(Boolean).length}/${results.length} Android design checks passed`);
