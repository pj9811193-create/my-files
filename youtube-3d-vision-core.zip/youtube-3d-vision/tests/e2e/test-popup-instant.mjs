/**
 * Focused check: the popup's readiness card is INSTANT.
 *  P1 first-ever open reaches the ready card
 *  P2 second open shows the ready card at domcontentloaded (no "Checking" flash)
 *  P3 no JS errors
 */
import puppeteer from 'puppeteer-core';

const results = [];
const record = (n, p, d='') => { results.push(p); console.log(`${p?'PASS':'FAIL'}  ${n}${d?'  ('+d+')':''}`); };
const CHROME = '/scratch/work/chrome-linux64/chrome';

const browser = await puppeteer.launch({
  executablePath: CHROME, headless: true,
  defaultViewport: { width: 1100, height: 700 },
  args: [
    '--no-sandbox', '--disable-setuid-sandbox',
    '--disable-extensions-except=/scratch/work/youtube-3d-vision',
    '--load-extension=/scratch/work/youtube-3d-vision',
    '--disable-dev-shm-usage',
  ],
});
try {
  const sw = await browser.waitForTarget((t) => t.type() === 'service_worker' && t.url().startsWith('chrome-extension://'), { timeout: 20000 });
  const extId = new URL(sw.url()).host;

  // ---- first-ever open: reaches ready (this primes the cache) ----
  {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    const t0 = Date.now();
    await page.goto(`chrome-extension://${extId}/popup.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => /Everything is ready|Almost hands-free/.test(document.querySelector('#modelcard')?.innerText || ''), { timeout: 15000 });
    const firstMs = Date.now() - t0;
    const firstText = await page.$eval('#modelcard', (el) => el.innerText.split('\n')[0]);
    record('P1 first-ever open reaches ready card', firstText.includes('Everything is ready'), `"${firstText}" in ${(firstMs/1000).toFixed(2)}s (first time only — this one primes the memory)`);
    await page.close();
  }

  // ---- second open: the card must ALREADY be ready the instant the page exists ----
  {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    const t0 = Date.now();
    await page.goto(`chrome-extension://${extId}/popup.html`, { waitUntil: 'domcontentloaded' });
    const instantText = await page.$eval('#modelcard', (el) => el.innerText.split('\n')[0]);
    const ms = Date.now() - t0;
    record('P2 second open: ready card shown immediately (no "Checking" flash)', instantText.includes('Everything is ready'), `"${instantText}" read at domcontentloaded, ${(ms/1000).toFixed(2)}s`);
    record('P3 no popup JS errors', errors.length === 0, errors[0]?.slice(0, 80) || '');
    await page.close();
  }
} finally { await browser.close(); }
const p = results.filter(Boolean).length;
console.log(`\n${p}/${results.length} popup-instant checks passed`);
