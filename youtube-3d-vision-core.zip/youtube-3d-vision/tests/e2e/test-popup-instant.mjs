/**
 * The popup's readiness card must be instant in every situation.
 *  P1 FIRST-EVER open: card already says ready at domcontentloaded (no check wait)
 *  P2 second open: same, instantly
 *  P3 no JS errors
 */
import puppeteer from 'puppeteer-core';

const results = [];
const record = (n, p, d='') => { results.push(p); console.log(`${p?'PASS':'FAIL'}  ${n}${d?'  ('+d+')':''}`); };

const browser = await puppeteer.launch({
  executablePath: '/scratch/work/chrome-linux64/chrome', headless: true,
  defaultViewport: { width: 1100, height: 700 },
  args: [
    '--no-sandbox', '--disable-setuid-sandbox',
    '--disable-extensions-except=/scratch/work/youtube-3d-vision',
    '--load-extension=/scratch/work/youtube-3d-vision',
    '--disable-dev-shm-usage',
  ],
});
try {
  const sw = await browser.waitForTarget((t) => t.type() === 'service_worker' && t.url().startsWith('chrome-extension://'), { timeout: 20000 });
  const extId = new URL(sw.url()).host;

  for (const [label] of [['FIRST-EVER OPEN'], ['SECOND OPEN']]) {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    const t0 = Date.now();
    await page.goto(`chrome-extension://${extId}/popup.html`, { waitUntil: 'domcontentloaded' });
    const ms = Date.now() - t0;
    // read the card IMMEDIATELY - no waiting allowed
    const title = await page.$eval('#modelcard .cardtitle', (el) => el.textContent.trim());
    const body = await page.$eval('#modelcard .cardtext', (el) => el.textContent.trim());
    record(`P ${label}: card says ready immediately`, title.includes('Everything is ready'),
      `"${title}" at ${(ms/1000).toFixed(2)}s`);
    await page.close();
    if (label === 'FIRST-EVER OPEN') record('P3 no popup JS errors', errors.length === 0, errors[0]?.slice(0, 80) || '');
  }
} finally { await browser.close(); }
console.log(`\n${results.filter(Boolean).length}/${results.length} checks passed`);
