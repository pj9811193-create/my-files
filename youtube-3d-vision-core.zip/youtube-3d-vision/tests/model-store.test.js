/**
 * Unit tests for src/lib/model-store.js — the CDN + IndexedDB model cache.
 * All external effects are mocked (fetch / idbGet / idbPut).
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  MODEL_FILE, MODEL_SOURCES,
  fetchModelFromCDN, ensureModel, isModelCached,
} from '../src/lib/model-store.js';

const BIG = 2_000_000; // > MIN_MODEL_BYTES

function fakeFetchOk(size, { stream = true } = {}) {
  const bytes = new Uint8Array(size);
  const res = {
    ok: true, status: 200,
    headers: new Map([['content-length', String(size)]]),
  };
  if (stream) {
    res.body = {
      getReader: () => {
        let sent = false;
        return {
          read: async () => {
            if (sent) return { done: true, value: undefined };
            sent = true;
            return { done: false, value: bytes };
          },
        };
      },
    };
  } else {
    res.arrayBuffer = async () => bytes.buffer;
  }
  return async () => res;
}

test('fetchModelFromCDN streams the first working source and reports progress', async () => {
  const seen = [];
  const bytes = await fetchModelFromCDN(
    (p) => seen.push(p),
    { fetch: fakeFetchOk(BIG) }
  );
  assert.equal(bytes.length, BIG);
  assert.equal(seen.length, 1);
  assert.equal(seen[0].loaded, BIG);
  assert.equal(seen[0].total, BIG);
});

test('fetchModelFromCDN falls back to the second CDN mirror', async () => {
  let calls = 0;
  const fetchFn = async (url) => {
    calls++;
    if (url === MODEL_SOURCES[0]) {
      const e = new Error('connection reset'); throw e;
    }
    return fakeFetchOk(BIG)();
  };
  const bytes = await fetchModelFromCDN(null, { fetch: fetchFn });
  assert.equal(bytes.length, BIG);
  assert.equal(calls, 2);
});

test('fetchModelFromCDN rejects a too-small (error page) download and tries the next mirror', async () => {
  const fetchFn = async (url) => (url === MODEL_SOURCES[0] ? fakeFetchOk(500)() : fakeFetchOk(BIG)());
  const bytes = await fetchModelFromCDN(null, { fetch: fetchFn });
  assert.equal(bytes.length, BIG);
});

test('fetchModelFromCDN throws when every mirror fails', async () => {
  await assert.rejects(
    () => fetchModelFromCDN(null, { fetch: async () => { throw new Error('offline'); } }),
    /could not download the model from any source/
  );
});

test('ensureModel downloads once from the CDN and stores the whole model in IndexedDB', async () => {
  const puts = [];
  const result = await ensureModel({
    deps: {
      fetch: fakeFetchOk(BIG),
      idbGet: async () => null,
      idbPut: async (key, blob) => { puts.push([key, blob]); return true; },
    },
  });
  assert.equal(result.fromCache, false);
  assert.equal(result.bytes.length, BIG);
  assert.equal(puts.length, 1);
  assert.equal(puts[0][0], MODEL_FILE);
  assert.equal(puts[0][1].size, BIG, 'the whole model is stored');
});

test('ensureModel serves from the IndexedDB cache with zero downloads', async () => {
  let fetched = 0;
  const result = await ensureModel({
    deps: {
      fetch: async () => { fetched++; throw new Error('must not be called'); },
      idbGet: async () => ({ size: BIG, arrayBuffer: async () => new Uint8Array(BIG).buffer }),
      idbPut: async () => { throw new Error('must not be called'); },
    },
  });
  assert.equal(result.fromCache, true);
  assert.equal(result.bytes.length, BIG);
  assert.equal(fetched, 0);
});

test('a too-small cached entry is treated as a cache miss', async () => {
  const result = await ensureModel({
    deps: {
      fetch: fakeFetchOk(BIG),
      idbGet: async () => ({ size: 42, arrayBuffer: async () => new ArrayBuffer(42) }),
      idbPut: async () => true,
    },
  });
  assert.equal(result.fromCache, false);
});

test('isModelCached reports true only for a plausibly-sized entry', async () => {
  assert.equal(await isModelCached({ idbGet: async () => ({ size: BIG }) }), true);
  assert.equal(await isModelCached({ idbGet: async () => ({ size: 10 }) }), false);
  assert.equal(await isModelCached({ idbGet: async () => null }), false);
  assert.equal(await isModelCached({ idbGet: async () => { throw new Error('idb blocked'); } }), false);
});
