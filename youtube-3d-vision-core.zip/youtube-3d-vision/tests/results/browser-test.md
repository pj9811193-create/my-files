# Browser end-to-end test results

Date: 2026-09-30 (latest run: Phase D)
Browser: Chrome for Testing 153 (headless), WebGL2 via SwiftShader, VP9/WebM playback
Phases: A + A2 (full pipeline regression, run 27 checks) | C (zero-click CDN fallback, 5 checks) | D (bundled model, instant first use, 6 checks)

## Phase A + A2: full pipeline (separate run, bundled model removed — CDN path exercised)

Local YouTube-DOM stand-in, real VP9 playback: injection, model load, live inference, disparity, SBS, 2D, seek, pause, FPS/latency, backend switch, fullscreen, SPA video change, 360 head tracking, alignment, protected (cross-origin) video.

| Check | Result | Detail |
| --- | --- | --- |
| A1 3D Vision button appears in player controls | PASS |  |
| A2 video plays normally | PASS | 3.5s -> 5.0s |
| A3 control panel opens | PASS |  |
| A3b WebGPU renderer auto-selected and initialized (WGSL compiled, pipelines created) | PASS | renderer: WebGPU |
| A3c WebGPU canvas presentation is broken in this software-GPU environment - pixels unverifiable here (documented limitation) | PASS | isolated red-clear WebGPU canvas also stays blank in this browser |
| A3d backend switch rebuilds the renderer to WebGL2 | PASS | renderer: WebGL2 |
| A4 AI depth inference active (model loaded, worker ready) | PASS | AI depth active (wasm |
| A5 zero-separation output is a clean mono frame | PASS | |R-G| mean = 0 |
| A6 left/right views have measurable disparity | PASS | |R-G| mean sep0: 0 vs sep1: 21, p95 sep1: 65 (gray levels |
| A7 side-by-side mode renders | PASS | canvas 960x540 |
| A8 SBS halves differ (two distinct views) | PASS | |R-G| = 20 |
| A9 2D passthrough mode renders the natural frame (no anaglyph split) | PASS | |G-B| = 21 |
| A10 seeking works while 3D is enabled | PASS | t=120.0s, "AI depth active (wasm)" |
| A11 FPS/latency monitor live | PASS | 6 fps, 4446 ms, reuse 0% |
| A12 acceleration status reported honestly | PASS | backend: CPU |
| A13 pausing playback is handled gracefully | PASS | "AI depth active (wasm)" |
| A14 no page-level JS errors from the extension | PASS |  |
| A15 modern renderer active (WebGPU preferred, WebGL2 fallback) | PASS | renderer: WebGL2 |
| A16 memory usage monitored (JS heap readout live) | PASS | heap: 4 MB |
| A17 fullscreen: overlay stays fitted + pipeline active | PASS | {"fitted":true,"visible":true,"status":"AI depth active (wasm)"} |
| A19 360 head-tracked viewing responds to orientation events | PASS | mean pixel delta after synthetic rotation: 55 |
| A20 screen alignment control shifts the rendered frame | PASS | mean pixel delta at alignX=0.1: 43 |
| A18 video change (SPA): pipeline re-attaches to the new video | PASS | new video detected, worker + renderer rebuilt, depth active |
| P1 protected fixture check (cross-origin frames unreadable) | PASS |  |
| P2 protected video fails gracefully (clear error, no overlay) | PASS | "Error: Video frames are not readable in this context." canvasVisible=false |
| P3 playback continues untouched on protected video | PASS | paused=false, t=undefined |
| P4 no page errors on protected video | PASS |  |

## Phase C: zero-click model delivery (separate run, fresh profile, no bundled model)

No `models/midas_v21_small_256.onnx` anywhere on disk; the inference worker must fetch it itself from a CDN mirror (CORS), store the whole file in the site's IndexedDB, and run inference from those bytes.

| Check | Result | Detail |
| --- | --- | --- |
| C1 no model file bundled in the extension copy (CDN path genuinely exercised) | PASS |  |
| C2 3D becomes active with zero manual setup (worker fetches the model from the CDN on first use) | PASS | AI depth active (wasm |
| C4 anaglyph stereo output from the CDN-sourced model shows measurable disparity | PASS | |R-G| sep0: 0 vs sep1: 19, p95 62 |
| C5 whole model stored in page IndexedDB; popup reports ready via status relay | PASS | IndexedDB record 66.4 MB; popup card: "✓ Everything is ready" |
| C6 no page JS errors during the zero-click flow | PASS |  |

## Phase D: bundled model — instant first use, zero downloads (separate run, fresh profile)

The shipped configuration: model included in `models/`. First use must be instant — no CDN fetch, no IndexedDB write.

| Check | Result | Detail |
| --- | --- | --- |
| D1 model file is bundled with the extension copy | PASS |  |
| D2 first use is instant: AI depth active from the bundled model, no download status ever shown | PASS | AI depth active (wasm) (ready in 20.0s, download status seen: false |
| D3 no CDN download happened: page IndexedDB has no model record | PASS | record size: 0 |
| D4 anaglyph stereo output from the bundled model shows measurable disparity | PASS | |R-G| sep0: 0 vs sep1: 19, p95 65 |
| D5 popup reports "Everything is ready" from the bundled-model check (no download path used) | PASS | ✓ Everything is ready |
| D6 no page JS errors during the bundled-model flow | PASS |  |

**Totals: 38 checks passed, 0 failed.** (Phase B, real youtube.com playback, remains excluded in this environment: datacenter-IP CAPTCHA, as documented in the QA report.)
