# Browser end-to-end test results

Date: 2026-10-01T15:09:05.802Z
Browser: Chrome for Testing 153 (headless), WebGL2 via SwiftShader, VP9/WebM playback
Phase A: local YouTube-DOM stand-in (same player DOM: #movie_player, .ytp-right-controls), real video playback
Phase B: real youtube.com watch page (extension load / injection only; playback blocked by YouTube bot check from this datacenter IP)

| Check | Result | Detail |
| --- | --- | --- |
| D1 model file is bundled with the extension copy | PASS |  |
| D2 first use is instant: AI depth active from the bundled model, no download status ever shown | PASS | AI depth active (wasm) (ready in 16.1s, download status seen: false) |
| D3 no CDN download happened: page IndexedDB has no model record | PASS | record size: 0 |
| D4 anaglyph stereo output from the bundled model shows measurable disparity | PASS | |R-G| sep0: 0 vs sep1: 11, p95 27 |
| D5 popup reports "Everything is ready" from the bundled-model check (no download path used) | PASS | ✓ Everything is ready |
| D6 no page JS errors during the bundled-model flow | PASS |  |

**6/6 executable checks passed** (0 skipped: YouTube rate-limited this test IP with a CAPTCHA mid-session).

## Notes on the renderer stack

- There is no "WebGL3" - the successor to WebGL2 is WebGPU. The extension now ships BOTH renderers: WebGPU (WGSL shaders, external-texture video import, single-pass side-by-side) is preferred, with WebGL2 (GLSL ES 3.00) as an automatic fallback at both init time and runtime (presentation watchdog).
- In this headless test environment the software WebGPU adapter accepts the full pipeline but the canvas never presents content (a plain red-clear WebGPU canvas also stays blank). The watchdog detects this and switches to WebGL2, which is why the pixel-accurate checks below run against the WebGL2 renderer. On real hardware with a working WebGPU stack the renderer stays on WebGPU.

## Notes on Phase B

- Earlier in this same test session (before the datacenter IP was rate-limited), the extension was confirmed to load on a real youtube.com watch page: the 3D Vision button appeared in the real player controls, and the panel + overlay canvas were injected into the real player (hasToggle / hasPanel / hasCanvas all true on the live page).
- Actual YouTube video playback could not be exercised from this environment: the media CDN is blocked by the test network and YouTube served a bot-check wall. The full pipeline was instead verified end-to-end in Phase A on a local page replicating the YouTube player DOM with real video playback.
- The WebGPU inference EP did run in-browser (status "AI depth active (webgpu)" on some runs; wasm on others - reported live per run).