import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  sampleShiftU,
  measuredDisparityPx,
  MAX_DISPARITY_UV,
  resolveQuality,
  QUALITY_PROFILES,
  clamp01,
} from '../src/lib/stereo-math.js';

const OPTS = { strength: 1, eyeSeparation: 1, convergence: 0.45 };

test('near objects shift positively, far objects negatively', () => {
  assert(sampleShiftU(1.0, OPTS) > 0); // nearest pixel
  assert(sampleShiftU(0.0, OPTS) < 0); // farthest pixel
});

test('the convergence plane gets zero parallax', () => {
  assert.equal(sampleShiftU(0.45, { ...OPTS, convergence: 0.45 }), 0);
});

test('shift magnitude scales with strength and eye separation', () => {
  const full = sampleShiftU(1.0, OPTS);
  assert.equal(sampleShiftU(1.0, { ...OPTS, strength: 0.5 }), full * 0.5);
  assert.equal(sampleShiftU(1.0, { ...OPTS, eyeSeparation: 0.25 }), full * 0.25);
  assert.equal(sampleShiftU(1.0, { strength: 0, eyeSeparation: 1, convergence: 0.45 }), 0);
});

test('shift is bounded by the maximum disparity', () => {
  assert.ok(Math.abs(sampleShiftU(1.0, OPTS)) <= MAX_DISPARITY_UV + 1e-12);
  assert.ok(Math.abs(sampleShiftU(0.0, OPTS)) <= MAX_DISPARITY_UV + 1e-12);
});

test('measured left/right disparity is non-zero in pixels on a real canvas width', () => {
  // 1280px-wide canvas, near object vs far object -> visibly different positions.
  const near = measuredDisparityPx(0.9, OPTS, 1280);
  const far = measuredDisparityPx(0.1, OPTS, 1280);
  assert.ok(near > 30, `expected >30px disparity for near, got ${near}`);
  assert.ok(far < -30, `expected <-30px disparity for far, got ${far}`);
  assert.ok(near > far);
});

test('quality profiles are monotonic: high infers more often than low', () => {
  assert.ok(QUALITY_PROFILES.high.inferIntervalMs < QUALITY_PROFILES.medium.inferIntervalMs);
  assert.ok(QUALITY_PROFILES.medium.inferIntervalMs < QUALITY_PROFILES.low.inferIntervalMs);
  assert.deepEqual(resolveQuality('nope'), QUALITY_PROFILES.medium);
  assert.deepEqual(resolveQuality('low'), QUALITY_PROFILES.low);
});

test('clamp01', () => {
  assert.equal(clamp01(-1), 0);
  assert.equal(clamp01(2), 1);
  assert.equal(clamp01(0.3), 0.3);
});
