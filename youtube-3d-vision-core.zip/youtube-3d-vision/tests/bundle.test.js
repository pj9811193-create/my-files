import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');

/**
 * Static sanity checks on the extension bundle: manifest validity, file
 * presence, and that every shader compiles as GLSL ES 3.00 (checked
 * textually here; true GPU compilation is covered by the browser test).
 */
test('manifest.json parses and declares required MV3 fields', () => {
  const m = JSON.parse(readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  assert.equal(m.manifest_version, 3);
  assert.ok(m.content_scripts[0].js.includes('content.js'));
  assert.equal(m.background.service_worker, 'background.js');
  assert.ok(m.web_accessible_resources[0].resources.includes('src/*'));
});

test('all referenced source files exist', () => {
  const files = [
    'content.js', 'background.js', 'popup.html', 'popup.js', 'styles.css',
    'src/main.js', 'src/settings.js', 'src/video-detector.js', 'src/panel.js',
    'src/frame-processor.js', 'src/depth-engine.js', 'src/stereo-renderer.js',
    'src/stereo-renderer-webgpu.js', 'src/renderer-factory.js',
    'src/lib/stereo-math.js', 'src/lib/depth-post.js', 'src/lib/idb.js',
    'shaders/fullscreen.vert.glsl', 'shaders/stereo.frag.glsl', 'shaders/pano360.frag.glsl',
    'icons/icon16.png', 'icons/icon48.png', 'icons/icon128.png',
    'vendor/onnxruntime-web/ort.all.min.mjs',
  ];
  for (const f of files) {
    assert.ok(exists(path.join(root, f)), `missing: ${f}`);
  }
});

function exists(p) {
  try { execFileSync('test', ['-f', p]); return true; } catch { return false; }
}

test('shaders declare GLSL ES 3.00 and the stereo shader has all modes', () => {
  const stereo = readFileSync(path.join(root, 'shaders/stereo.frag.glsl'), 'utf8');
  assert.ok(stereo.includes('#version 300 es'));
  for (const needle of ['uMode', 'uDisparity', 'uConvergence', 'uEye', 'uDepth', 'uVideo', 'uAlign']) {
    assert.ok(stereo.includes(needle), `stereo shader missing ${needle}`);
  }
  const pano = readFileSync(path.join(root, 'shaders/pano360.frag.glsl'), 'utf8');
  for (const needle of ['uYaw', 'uPitch', 'uFov']) {
    assert.ok(pano.includes(needle), `pano shader missing ${needle}`);
  }
});

test('WebGPU renderer implements the same interface and WGSL shaders are present', () => {
  const gpu = readFileSync(path.join(root, 'src/stereo-renderer-webgpu.js'), 'utf8');
  for (const needle of ['@vertex', '@fragment', 'texture_external', 'importExternalTexture',
    'createRenderPipeline', 'setDepth', 'render(video)', 'setMode', 'setVisible', 'fit']) {
    assert.ok(gpu.includes(needle), `WebGPU renderer missing ${needle}`);
  }
  const factory = readFileSync(path.join(root, 'src/renderer-factory.js'), 'utf8');
  assert.ok(factory.includes('WebGPURenderer') && factory.includes('StereoRenderer'));
  // Presentation watchdog must exist (runtime WebGPU -> WebGL2 fallback).
  assert.ok(gpu.includes('_presentationProbe') && gpu.includes('onFailure'));
  // Screen alignment + head tracking implemented in both renderers.
  assert.ok(gpu.includes('alignX') && gpu.includes('alignY'));
  assert.ok(gpu.includes('DeviceOrientationEvent') && gpu.includes('deviceorientation'));
  const webgl = readFileSync(path.join(root, 'src/stereo-renderer.js'), 'utf8');
  assert.ok(webgl.includes('DeviceOrientationEvent'));
  assert.ok(readFileSync(path.join(root, 'src/frame-processor.js'), 'utf8').includes('performance.memory'));
  assert.ok(readFileSync(path.join(root, 'src/panel.js'), 'utf8').includes('yt3d-mem'));
  const main = readFileSync(path.join(root, 'src/main.js'), 'utf8');
  assert.ok(main.includes('renderer.onFailure') && main.includes('StereoRenderer.create'));
  // The GLSL SBS eye convention must match the WGSL one (left eye samples +shift).
  const glsl = readFileSync(path.join(root, 'shaders/stereo.frag.glsl'), 'utf8');
  assert.ok(glsl.includes('float(-uEye) * shift'));
  assert.ok(gpu.includes('su + vec2<f32>(shift, 0.0)'));
});

test('worker uses the verified MiDaS I/O contract', () => {
  const worker = readFileSync(path.join(root, 'src/depth-engine.js'), 'utf8');
  // Model verified in this environment: input [1,3,256,256], output [1,256,256].
  assert.ok(worker.includes('[1, 3, INPUT_SIZE, INPUT_SIZE]'));
  assert.ok(worker.includes('normalizeNearness'));
  // Temporal reuse must exist.
  assert.ok(worker.includes('shouldReuseDepth'));
});
