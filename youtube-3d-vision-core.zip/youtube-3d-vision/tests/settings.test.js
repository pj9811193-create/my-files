import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mergeSettings, DEFAULTS } from '../src/settings.js';

test('mergeSettings keeps defaults for an empty patch', () => {
  assert.deepEqual(mergeSettings({}), DEFAULTS);
});

test('mergeSettings accepts valid values', () => {
  const s = mergeSettings({ depthStrength: 0.8, mode: 'sbs', quality: 'low' });
  assert.equal(s.depthStrength, 0.8);
  assert.equal(s.mode, 'sbs');
  assert.equal(s.quality, 'low');
});

test('mergeSettings clamps numeric values into range', () => {
  assert.equal(mergeSettings({ depthStrength: 5 }).depthStrength, 1);
  assert.equal(mergeSettings({ eyeSeparation: -3 }).eyeSeparation, 0);
  assert.equal(mergeSettings({ convergence: 0.7 }).convergence, 0.7);
});

test('mergeSettings handles screen alignment bounds', () => {
  assert.equal(mergeSettings({ alignX: 0.1, alignY: -0.05 }).alignX, 0.1);
  assert.equal(mergeSettings({ alignX: 9 }).alignX, 0.2);
  assert.equal(mergeSettings({ alignY: -9 }).alignY, -0.2);
  assert.equal(mergeSettings({}).alignX, DEFAULTS.alignX);
});

test('mergeSettings rejects unknown keys and invalid enum values', () => {
  const s = mergeSettings({ mode: 'VR-X9000', quality: 'ultra', malicious: true });
  assert.equal(s.mode, DEFAULTS.mode);
  assert.equal(s.quality, DEFAULTS.quality);
  assert.equal('malicious' in s, false);
});

test('mergeSettings rejects non-numeric garbage', () => {
  const s = mergeSettings({ depthStrength: 'lots' });
  assert.equal(s.depthStrength, DEFAULTS.depthStrength);
});
