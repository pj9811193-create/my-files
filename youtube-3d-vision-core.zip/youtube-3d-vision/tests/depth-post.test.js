import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeNearness,
  grayThumb32,
  meanAbsDiff,
  shouldReuseDepth,
  REUSE_DIFF_THRESHOLD,
} from '../src/lib/depth-post.js';

test('normalizeNearness maps min->0, max->1 and preserves ordering', () => {
  const raw = Float32Array.from([500, 200, 800, 650]);
  const n = normalizeNearness(raw);
  assert.equal(n[0], (500 - 200) / 600);
  assert.equal(n[1], 0);
  assert.equal(n[2], 1);
  assert.ok(n[3] > n[0] && n[0] > n[1]);
});

test('normalizeNearness handles a flat map without NaN', () => {
  const n = normalizeNearness(new Float32Array(16).fill(3.5));
  assert.ok(Number.isFinite(n[0]));
  assert.equal(n[0], 0);
});

test('normalizeNearness output stays within [0,1]', () => {
  const raw = Float32Array.from({ length: 4096 }, () => Math.random() * 1000);
  const n = normalizeNearness(raw);
  for (const v of n) assert.ok(v >= 0 && v <= 1);
});

test('grayThumb32 downsamples 256x256 RGBA to 32x32 luma', () => {
  const size = 256;
  const rgba = new Uint8ClampedArray(size * size * 4);
  // paint the top-left quadrant red-ish, rest blue-ish
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const topLeft = x < size / 2 && y < size / 2;
      rgba[i] = topLeft ? 255 : 0;
      rgba[i + 1] = 0;
      rgba[i + 2] = topLeft ? 0 : 255;
      rgba[i + 3] = 255;
    }
  }
  const g = grayThumb32(rgba, size);
  assert.equal(g.length, 32 * 32);
  const topLeftVal = g[0];
  const bottomRightVal = g[31 * 32 + 31];
  // red luma = 0.299*255 ~ 76, blue luma = 0.114*255 ~ 29
  assert.ok(Math.abs(topLeftVal - 76.2) < 1.5, `got ${topLeftVal}`);
  assert.ok(Math.abs(bottomRightVal - 29.1) < 1.5, `got ${bottomRightVal}`);
});

test('meanAbsDiff is 0 for identical arrays and symmetric', () => {
  const a = Float32Array.from([1, 2, 3]);
  const b = Float32Array.from([1, 2, 3]);
  assert.equal(meanAbsDiff(a, b), 0);
  assert.equal(meanAbsDiff(a, a), 0);
  assert.equal(meanAbsDiff(a, Float32Array.from([2, 3, 4])), 1);
});

test('shouldReuseDepth: static scene reuses, moving scene re-infers', () => {
  const still = Float32Array.from({ length: 1024 }, () => 100);
  assert.equal(shouldReuseDepth(still, still), true);

  const moved = Float32Array.from(still);
  for (let i = 0; i < moved.length; i++) moved[i] += REUSE_DIFF_THRESHOLD * 2;
  assert.equal(shouldReuseDepth(still, moved), false);
  assert.equal(shouldReuseDepth(null, still), false);

  // A tiny jitter below the threshold should still reuse.
  const jitter = Float32Array.from(still);
  for (let i = 0; i < jitter.length; i++) jitter[i] += 0.5;
  assert.equal(shouldReuseDepth(still, jitter), true);
});
