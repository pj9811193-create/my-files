/**
 * Starts checking whether the model is bundled the very moment the popup
 * begins to open — before popup.js has even loaded. Runs only inside the
 * extension; on a plain web page (e.g. a preview of this file) it does nothing.
 */
(function () {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) return;
  window.__bundledCheck = fetch(chrome.runtime.getURL('models/midas_v21_small_256.onnx'))
    .then((r) => { try { r.body && r.body.cancel(); } catch (_) {} return r.ok; })
    .catch(() => false);
})();
