/**
 * Starts checking whether the model is bundled the very moment the popup
 * begins to open — before popup.js has even loaded. (This must be an
 * external file: Manifest V3 blocks inline scripts in extension pages.)
 */
window.__bundledCheck = fetch(chrome.runtime.getURL('models/midas_v21_small_256.onnx'))
  .then((r) => { try { r.body && r.body.cancel(); } catch (_) {} return r.ok; })
  .catch(() => false);
