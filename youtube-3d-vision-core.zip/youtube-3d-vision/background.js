/**
 * Background service worker: relays the model-ready state from YouTube tabs
 * to the popup (tiny strings only — chrome.runtime messages cannot carry
 * binary payloads, and the model itself is fetched + cached by the inference
 * worker on the YouTube page origin, no round-trip needed).
 */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  // A YouTube tab reports that the model is now cached on its origin.
  if (msg.type === 'model-cached') {
    chrome.storage.session.set({ modelCached: !!msg.cached }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }
  // The popup asks for the last known state.
  if (msg.type === 'model-status') {
    chrome.storage.session.get('modelCached')
      .then(({ modelCached }) => sendResponse({ cached: !!modelCached }))
      .catch(() => sendResponse({ cached: false }));
    return true;
  }
});
